using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Icon = System.Drawing.Icon;

// Render the editable WPF vector master into Windows icon frames, without external packages.
internal static class IconBuilder
{
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            if (args.Length == 2 && args[0] == "--verify") { VerifyExecutable(args[1]); return 0; }
            if (args.Length != 2) throw new ArgumentException("Usage: IconBuilder <Icon.xaml> <assets directory> | --verify <exe>");
            DrawingImage master;
            using (Stream file = File.OpenRead(args[0])) master = (DrawingImage)XamlReader.Load(file);
            Directory.CreateDirectory(args[1]);
            int[] sizes = { 16, 20, 24, 32, 40, 48, 64, 128, 256 };
            List<byte[]> frames = new List<byte[]>();
            foreach (int size in sizes)
            {
                BitmapSource bitmap = Render(master, size);
                frames.Add(size == 256 ? Png(bitmap) : Dib(bitmap, size));
            }
            string ico = Path.Combine(args[1], "ip-pulse.ico");
            using (BinaryWriter writer = new BinaryWriter(File.Create(ico)))
            {
                writer.Write((ushort)0); writer.Write((ushort)1); writer.Write((ushort)sizes.Length);
                int offset = 6 + 16 * sizes.Length;
                for (int i = 0; i < sizes.Length; i++)
                {
                    writer.Write((byte)(sizes[i] == 256 ? 0 : sizes[i]));
                    writer.Write((byte)(sizes[i] == 256 ? 0 : sizes[i]));
                    writer.Write((byte)0); writer.Write((byte)0);
                    writer.Write((ushort)1); writer.Write((ushort)32);
                    writer.Write(frames[i].Length); writer.Write(offset); offset += frames[i].Length;
                }
                foreach (byte[] frame in frames) writer.Write(frame);
            }
            File.WriteAllBytes(Path.Combine(args[1], "ip-pulse.png"), Png(Render(master, 256)));
            // Pixel-size samples on both light and dark surfaces for visual QA.
            DrawingVisual sheet = new DrawingVisual();
            using (DrawingContext dc = sheet.RenderOpen())
            {
                dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, 520, 200));
                dc.DrawRectangle((Brush)new BrushConverter().ConvertFromString("#111C2D"), null, new Rect(0, 100, 520, 100));
                for (int row = 0; row < 2; row++)
                    for (int i = 0; i < 6; i++)
                    {
                        int size = sizes[i];
                        dc.DrawImage(master, new Rect(28 + i * 84, row * 100 + (100 - size) / 2.0, size, size));
                    }
            }
            RenderTargetBitmap preview = new RenderTargetBitmap(520, 200, 96, 96, PixelFormats.Pbgra32);
            preview.Render(sheet);
            File.WriteAllBytes(Path.Combine(args[1], "icon-sizes.png"), Png(preview));
            using (Stream stream = File.OpenRead(ico))
            {
                IconBitmapDecoder decoder = new IconBitmapDecoder(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
                foreach (int size in sizes)
                {
                    bool found = false;
                    foreach (BitmapFrame frame in decoder.Frames) if (frame.PixelWidth == size && frame.PixelHeight == size) found = true;
                    if (!found) throw new InvalidDataException("Missing decoded icon frame " + size);
                    // .NET Framework Icon's size selector does not select 256px PNG frames.
                    if (size < 256)
                        using (Icon icon = new Icon(ico, size, size))
                            if (icon.Width != size || icon.Height != size) throw new InvalidDataException("Wrong tray icon size " + size);
                }
            }
            Console.WriteLine("Generated and WPF-decoded 9 icon sizes (16-256 px); tray decoder passed 16-128 px.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
    }

    private static BitmapSource Render(DrawingImage master, int size)
    {
        DrawingVisual visual = new DrawingVisual();
        using (DrawingContext dc = visual.RenderOpen()) dc.DrawImage(master, new Rect(0, 0, size, size));
        RenderTargetBitmap bitmap = new RenderTargetBitmap(size, size, 96, 96, PixelFormats.Pbgra32);
        bitmap.Render(visual);
        return new FormatConvertedBitmap(bitmap, PixelFormats.Bgra32, null, 0);
    }

    private static byte[] Png(BitmapSource bitmap)
    {
        PngBitmapEncoder encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using (MemoryStream memory = new MemoryStream()) { encoder.Save(memory); return memory.ToArray(); }
    }

    private static byte[] Dib(BitmapSource bitmap, int size)
    {
        int stride = size * 4, maskStride = ((size + 31) / 32) * 4;
        byte[] pixels = new byte[stride * size]; bitmap.CopyPixels(pixels, stride, 0);
        using (MemoryStream memory = new MemoryStream())
        using (BinaryWriter writer = new BinaryWriter(memory))
        {
            writer.Write(40); writer.Write(size); writer.Write(size * 2);
            writer.Write((ushort)1); writer.Write((ushort)32);
            writer.Write(0); writer.Write(stride * size); writer.Write(0); writer.Write(0); writer.Write(0); writer.Write(0);
            for (int row = size - 1; row >= 0; row--) writer.Write(pixels, row * stride, stride);
            for (int row = size - 1; row >= 0; row--)
            {
                byte[] mask = new byte[maskStride];
                for (int x = 0; x < size; x++)
                    if (pixels[row * stride + x * 4 + 3] == 0) mask[x / 8] |= (byte)(128 >> (x % 8));
                writer.Write(mask);
            }
            return memory.ToArray();
        }
    }

    private static void VerifyExecutable(string path)
    {
        Assembly assembly = Assembly.LoadFile(Path.GetFullPath(path));
        foreach (int size in new[] { 16, 20, 24, 32, 48 })
            using (Stream stream = assembly.GetManifestResourceStream("IP-Pulse.ico"))
            using (Icon icon = new Icon(stream, size, size))
            {
                if (icon.Width != size) throw new InvalidDataException("Embedded tray icon size mismatch");
            }
        using (Icon native = Icon.ExtractAssociatedIcon(Path.GetFullPath(path)))
        using (System.Drawing.Bitmap bitmap = native.ToBitmap())
        {
            int mint = 0;
            for (int y = 0; y < bitmap.Height; y++)
                for (int x = 0; x < bitmap.Width; x++)
                {
                    System.Drawing.Color color = bitmap.GetPixel(x, y);
                    if (color.A > 180 && color.G > 160 && color.R < 150 && color.B > 120) mint++;
                }
            if (mint < 4) throw new InvalidDataException("Executable still contains the generic icon");
        }
        Console.WriteLine("PASS: EXE native icon and embedded tray icon (5 DPI sizes).");
    }
}
