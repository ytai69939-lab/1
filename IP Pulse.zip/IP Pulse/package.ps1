$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
Add-Type -AssemblyName System.IO.Compression.FileSystem
Copy-Item -LiteralPath (Join-Path $projectRoot 'VALIDATION.md') -Destination (Join-Path $projectRoot 'dist\VALIDATION.md') -Force
Copy-Item -LiteralPath (Join-Path $projectRoot 'CURRENT-ISSUES.md') -Destination (Join-Path $projectRoot 'dist\CURRENT-ISSUES.md') -Force
$portableFiles = @('IP Pulse.exe','IP Pulse.exe.config','README.md','LICENSE','VALIDATION.md','CURRENT-ISSUES.md') | ForEach-Object { Join-Path (Join-Path $projectRoot 'dist') $_ }
Compress-Archive -LiteralPath $portableFiles -DestinationPath (Join-Path $projectRoot 'IP Pulse-Windows.zip') -Force
# An explicit allowlist keeps personal settings and live IP diagnostic output out of both packages.
$sourceFiles = @(
    'src\App.config','src\app.manifest','src\Network.cs','src\AutomaticLookup.cs','src\Program.cs','src\Traffic.cs','src\Settings.xaml','src\Widget.xaml',
    'assets\Icon.xaml','assets\ip-pulse.ico','assets\ip-pulse.png','assets\icon-sizes.png','tools\IconBuilder.cs',
    'tests\CoreTests.cs','tests\TrafficTests.cs','tests\NetworkSafetyTests.cs','tests\AutomaticLookupTests.cs','build.ps1','build-icon.ps1','package.ps1','README.md','LICENSE','VALIDATION.md','AUDIT.md','CURRENT-ISSUES.md',
    'artifacts\preview.png','artifacts\preview-compact.png','artifacts\preview-settings.png','.gitignore'
)
$stream = [System.IO.File]::Open((Join-Path $projectRoot 'IP Pulse-Source.zip'),[System.IO.FileMode]::Create)
$archive = [System.IO.Compression.ZipArchive]::new($stream,[System.IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($relativeFile in $sourceFiles) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $projectRoot $relativeFile),$relativeFile.Replace('\','/'),[System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $archive.Dispose(); $stream.Dispose() }
Write-Output '已更新 Windows 便携包与源码包。'
