using System;
using System.Runtime.InteropServices;
using System.Threading;
using IPPulse;

internal static class TrafficTests
{
    internal static void Run(Action<bool, string> check)
    {
        TrafficAccumulator accumulator = new TrafficAccumulator();
        AdapterReading adapter = new AdapterReading { Id = "ethernet", Name = "Ethernet", IsUp = true, IsHardware = true, HasGateway = true, Received = 5000000000, Sent = 1000 };
        check(!accumulator.Observe(adapter, 100).Ready, "traffic first sample warms up");
        adapter.Received += 2048; adapter.Sent += 1024;
        TrafficResult rate = accumulator.Observe(adapter, 102);
        check(rate.Ready && rate.DownloadBytesPerSecond == 1024 && rate.UploadBytesPerSecond == 512, "traffic uses counter deltas / actual elapsed seconds");
        check(rate.DownloadBytesPerSecond < 1000000, "traffic lifetime totals are not rates");
        rate = accumulator.Observe(adapter, 103);
        check(rate.Ready && rate.DownloadBytesPerSecond == 0 && rate.UploadBytesPerSecond == 0, "idle traffic reports zero");
        adapter.Received = 1; adapter.Sent = 0;
        check(!accumulator.Observe(adapter, 104).Ready, "counter reset never produces a negative speed");
        adapter.Received += 300; adapter.Sent += 100;
        check(accumulator.Observe(adapter, 105).DownloadBytesPerSecond == 300, "counter reset recovers on next sample");
        check(!accumulator.Observe(adapter, 105).Ready, "zero elapsed time does not divide by zero");
        check(!accumulator.Observe(adapter, 104).Ready, "clock reversal does not create a rate");
        check(!accumulator.Observe(adapter, 120).Ready, "sleep or long sampling gap resets baseline");
        adapter.IsUp = false;
        check(!accumulator.Observe(adapter, 121).Ready, "disconnected adapter is unavailable");
        adapter.IsUp = true;
        check(!accumulator.Observe(adapter, 122).Ready, "reconnected adapter warms up");
        AdapterReading tunnel = new AdapterReading { Id = "tun", Name = "TUN", IsUp = true, PreferredRoute = true, HasGateway = true, Received = 9999999999, Sent = 9999999999 };
        check(!accumulator.Observe(tunnel, 123).Ready, "switching adapters does not mix counters");
        check(!accumulator.Observe(null, 124).Ready, "missing adapter clears old sample");
        check(TrafficMonitor.SelectAdapter(new[] { tunnel, adapter }, "") == adapter, "auto prefers physical link over its TUN");
        check(TrafficMonitor.SelectAdapter(new[] { tunnel, adapter }, "tun") == tunnel, "manual selection can monitor only TUN");
        check(TrafficMonitor.SelectAdapter(new[] { tunnel, adapter }, "missing") == null, "missing manual adapter does not silently change scope");
        AdapterReading offline = new AdapterReading { Id = "offline", Name = "Offline", IsHardware = true, HasGateway = true };
        check(TrafficMonitor.SelectAdapter(new[] { offline, tunnel }, "") == tunnel, "auto skips offline physical adapter");
        AdapterReading wifi = new AdapterReading { Id = "wifi", Name = "Wi-Fi", IsUp = true, IsHardware = true, HasGateway = true, PreferredRoute = true };
        check(TrafficMonitor.SelectAdapter(new[] { adapter, wifi }, "") == wifi, "preferred route breaks physical adapter tie");
        check(TrafficMonitor.SelectAdapter(new AdapterReading[0], "") == null, "empty adapter list is handled");
        check(TrafficMonitor.FormatRate(0) == "0 B/s", "zero rate format");
        check(TrafficMonitor.FormatRate(512) == "512 B/s", "bytes per second format");
        check(TrafficMonitor.FormatRate(1024) == "1.00 KB/s", "KB boundary");
        check(TrafficMonitor.FormatRate(1048576) == "1.00 MB/s", "MB boundary");
        check(TrafficMonitor.FormatRate(1073741824) == "1.00 GB/s", "GB boundary");
        check(TrafficMonitor.FormatRate(double.NaN) == "—" && TrafficMonitor.FormatRate(-1) == "—", "invalid speed is not fabricated");
        check(Marshal.SizeOf(typeof(TrafficMonitor.NativeInterfaceRow)) == 1352, "Windows MIB_IF_ROW2 marshaling size");
    }

    internal static int Live()
    {
        TrafficMonitor monitor = new TrafficMonitor();
        TrafficResult first = monitor.Read("");
        if (first.Adapters.Length == 0) throw new Exception(first.Message);
        Thread.Sleep(1250);
        TrafficResult next = monitor.Read("");
        if (!next.Ready) throw new Exception(next.Message);
        Console.WriteLine("PASS live counters: " + next.AdapterName + " / down " + TrafficMonitor.FormatRate(next.DownloadBytesPerSecond) + " / up " + TrafficMonitor.FormatRate(next.UploadBytesPerSecond));
        Console.WriteLine("Interfaces: " + next.Adapters.Length + "; counted: 1; no test download or upload performed.");
        return 0;
    }
}
