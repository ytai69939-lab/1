using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IPPulse;

internal static class CoreTests
{
    private static int checks;
    private static void Check(bool condition, string label)
    { if (!condition) throw new Exception("FAIL: " + label); checks++; Console.WriteLine("PASS " + label); }
    private static void Throws(Action action, string label)
    { bool thrown = false; try { action(); } catch { thrown = true; } Check(thrown, label); }

    public static int Main(string[] args)
    {
        try { if (args.Length > 0 && args[0] == "--traffic-live") return TrafficTests.Live(); TrafficTests.Run(Check); Run().GetAwaiter().GetResult(); Console.WriteLine("ALL " + checks + " CHECKS PASSED"); return 0; }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
    }

    private static async Task Run()
    {
        await NetworkSafetyTests.Run(Check);
        foreach (int status in new[] { 200, 204, 299 })
            Check(NetworkMonitor.Classify("https://chatgpt.com/", "https://chatgpt.com/", status, 123, false).State == "ok", "2xx " + status);
        foreach (int status in new[] { 301, 401, 403, 407, 404, 429 })
            Check(NetworkMonitor.Classify("https://chatgpt.com/", "https://chatgpt.com/", status, 123, false).State == "limited", "restricted " + status);
        Check(NetworkMonitor.Classify("https://chatgpt.com/", "https://chatgpt.com/", 503, 123, false).State == "error", "503 is server error");
        Check(NetworkMonitor.Classify("https://chatgpt.com/", "https://chatgpt.com/", 200, 123, true).State == "limited", "challenge on HTTP 200");
        Check(NetworkMonitor.Classify("https://openai.com/", "https://www.openai.com/", 200, 123, false).State == "ok", "same-site redirect");
        Check(NetworkMonitor.Classify("https://openai.com/", "https://openai.com.evil.invalid/", 200, 123, false).State == "limited", "lookalike redirect");
        Check(NetworkMonitor.Classify("https://openai.com/", "http://openai.com/", 200, 123, false).State == "limited", "HTTPS downgrade");
        Check(NetworkMonitor.Classify("https://chatgpt.com/", "https://chatgpt.com/", 403, 123, false).Milliseconds == 123, "blocked response keeps measured latency");

        IpResult china = NetworkMonitor.ParsePrimary("{\"ip\":\"8.8.8.8\",\"pro\":\"广东省\",\"city\":\"深圳市\",\"addr\":\"广东省深圳市\"}");
        Check(china.Success && china.City == "深圳市" && china.Location == "广东省 · 深圳市", "Chinese location parsing");
        Check(NetworkMonitor.ParsePrimary("{\"ip\":\"8.8.8.8\",\"addr\":\"美国\"}").Location.Contains("城市未知"), "missing city is not invented");
        IpResult ipv6 = NetworkMonitor.ParseFallback("{\"ip\":\"2606:4700:4700::1111\",\"success\":true,\"city\":\"Tokyo\",\"region\":\"Tokyo\",\"country\":\"Japan\",\"connection\":{\"isp\":\"Example\"}}");
        Check(ipv6.Success && ipv6.Location == "Japan · Tokyo" && ipv6.Isp == "Example", "IPv6 and repeated region parsing");
        Throws(delegate { NetworkMonitor.ParseFallback("{\"success\":false,\"message\":\"quota\"}"); }, "provider failure");
        Throws(delegate { NetworkMonitor.ParsePrimary("<html>challenge</html>"); }, "reject HTML response");
        Throws(delegate { NetworkMonitor.ParsePrimary("{\"ip\":\"garbage\"}"); }, "reject invalid IP");
        foreach (string ip in new[] { "127.0.0.1", "10.1.2.3", "192.168.1.1", "172.31.0.1", "169.254.1.1", "100.64.0.1", "::1", "fe80::1", "fc00::1", "::ffff:192.168.1.1" })
            Check(!NetworkMonitor.IsPublicAddress(ip), "exclude local " + ip);
        Check(NetworkMonitor.IsPublicAddress("8.8.8.8"), "public IPv4");
        Throws(delegate { Settings.ValidateProxy("socks5://localhost:7890"); }, "SOCKS rejected explicitly");
        Throws(delegate { Settings.ValidateProxy("http://user:secret@localhost:7890"); }, "credentials not stored in proxy URI");
        Throws(delegate { Settings.ValidateProxy("http://localhost:7890/path"); }, "proxy path rejected");
        Check(Settings.ValidateProxy("http://127.0.0.1:7890").Port == 7890, "valid HTTP proxy");
        Settings limits = new Settings { IpSource = "legacy", IntervalSeconds = 0, TimeoutSeconds = 500, ProxyMode = "system" }; limits.Normalize();
        Check(limits.IntervalSeconds == 5 && limits.TimeoutSeconds == 20 && limits.ProxyMode == "system", "settings bounds");
        Throws(delegate { new Settings { ProxyMode = "typo" }.Normalize(); }, "invalid proxy mode fails closed without system proxy fallback");
        string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "test-settings.json");
        new Settings().Save(path);
        Check(Settings.Load(path).IntervalSeconds == 10, "settings first save handles NaN");
        new Settings { IpSource = "legacy", IntervalSeconds = 30, Topmost = false }.Save(path);
        Check(Settings.Load(path).IntervalSeconds == 30 && !Settings.Load(path).Topmost, "settings atomic replacement");

        using (TestServer server = new TestServer())
        using (NetworkMonitor monitor = new NetworkMonitor(new Settings { IpSource = "legacy", ProxyMode = "direct", TimeoutSeconds = 2 }, server.Url + "primary", server.Url + "fallback"))
        {
            IpResult ip = await monitor.GetIpAsync(CancellationToken.None);
            Check(ip.Success && ip.City == "Test City" && ip.Source.Contains("备用"), "primary error falls back");
            Check(ip.RetryAfterSeconds > 0 && ip.RetryAfterSeconds <= 90, "fallback IP mode schedules earliest provider retry");
            ProbeResult forbidden = await monitor.ProbeAsync(server.Url + "forbidden", CancellationToken.None);
            Check(forbidden.HttpStatus == 403 && forbidden.Milliseconds.HasValue && forbidden.State == "limited", "real HTTP 403 measured");
            ProbeResult rate = await monitor.ProbeAsync(server.Url + "rate", CancellationToken.None);
            Check(rate.HttpStatus == 429 && rate.RetryAfterSeconds == 120, "Retry-After preserved");
            ProbeResult timeout = await monitor.ProbeAsync(server.Url + "slow", CancellationToken.None);
            Check(timeout.State == "offline" && timeout.Label == "超时" && !timeout.Milliseconds.HasValue, "timeout does not fabricate latency");
            using (CancellationTokenSource cancel = new CancellationTokenSource(80))
            {
                bool cancelled = false;
                try { await monitor.ProbeAsync(server.Url + "slow", cancel.Token); } catch (OperationCanceledException) { cancelled = true; }
                Check(cancelled, "caller cancellation propagates");
            }
            using (CancellationTokenSource cancel = new CancellationTokenSource(80))
            {
                bool cancelled = false;
                using (NetworkMonitor slowIp = new NetworkMonitor(new Settings { IpSource = "legacy", ProxyMode = "direct", TimeoutSeconds = 2 }, server.Url + "slow", server.Url + "fallback"))
                    try { await slowIp.GetIpAsync(cancel.Token); } catch (OperationCanceledException) { cancelled = true; }
                Check(cancelled, "IP cancellation does not start fallback");
            }
            using (NetworkMonitor oversized = new NetworkMonitor(new Settings { IpSource = "legacy", ProxyMode = "direct", TimeoutSeconds = 2 }, server.Url + "large", server.Url + "fallback"))
                Check((await oversized.GetIpAsync(CancellationToken.None)).City == "Test City", "oversized response rejected and fallback used");
            using (NetworkMonitor same = new NetworkMonitor(new Settings { IpSource = "legacy", ProxyMode = "direct", TimeoutSeconds = 2 }, server.Url + "same", server.Url + "fallback"))
            {
                IpResult first = await same.GetIpAsync(CancellationToken.None);
                IpResult second = await same.GetIpAsync(CancellationToken.None);
                Check(first.City == "Test City" && second.City == "Test City", "city enrichment requires matching IP");
                Check(second.Source.Contains("缓存"), "city lookup cache reduces quota use");
            }
            using (NetworkMonitor mismatch = new NetworkMonitor(new Settings { IpSource = "legacy", ProxyMode = "direct", TimeoutSeconds = 2 }, server.Url + "different", server.Url + "fallback"))
            {
                IpResult result = await mismatch.GetIpAsync(CancellationToken.None);
                Check(result.Address == "1.1.1.1" && string.IsNullOrEmpty(result.City), "different egress IPs are not merged");
            }
            using (NetworkMonitor gbk = new NetworkMonitor(new Settings { IpSource = "legacy", ProxyMode = "direct", TimeoutSeconds = 2 }, server.Url + "gbk", server.Url + "fallback"))
                Check((await gbk.GetIpAsync(CancellationToken.None)).City == "深圳市", "GBK response decoding");
            IpLookupState limitedState = new IpLookupState();
            using (NetworkMonitor limited = new NetworkMonitor(new Settings { IpSource = "legacy", ProxyMode = "direct", TimeoutSeconds = 2 }, server.Url + "primary", server.Url + "rate", limitedState))
                Check((await limited.GetIpAsync(CancellationToken.None)).RetryAfterSeconds <= 30 && limitedState.Remaining(false) >= 119, "provider quota respected without delaying primary retry");
        }
    }

    private sealed class TestServer : IDisposable
    {
        private readonly TcpListener listener;
        public readonly string Url;
        private volatile bool closed;
        public TestServer()
        {
            listener = new TcpListener(IPAddress.Loopback, 0); listener.Start();
            Url = "http://127.0.0.1:" + ((IPEndPoint)listener.LocalEndpoint).Port + "/";
            Task.Run((Func<Task>)Accept);
        }
        private async Task Accept()
        {
            while (!closed)
                try { TcpClient client = await listener.AcceptTcpClientAsync(); StartServing(client); }
                catch (ObjectDisposedException) { break; }
                catch (SocketException) { break; }
        }
        private void StartServing(TcpClient client) { Task.Run(() => Serve(client)); }
        private async Task Serve(TcpClient client)
        {
            using (client)
            try
            {
                NetworkStream stream = client.GetStream();
                StreamReader reader = new StreamReader(stream, Encoding.ASCII, false, 1024, true);
                string line = await reader.ReadLineAsync();
                if (line == null) return;
                string route = line.Split(' ')[1];
                while (!string.IsNullOrEmpty(await reader.ReadLineAsync())) { }
                if (route == "/slow") await Task.Delay(3200);
                int status = route == "/primary" ? 503 : route == "/forbidden" ? 403 : route == "/rate" ? 429 : 200;
                string body = route == "/large" ? new string('x', 70000) :
                    route == "/same" ? "{\"ip\":\"8.8.8.8\"}" :
                    route == "/different" ? "{\"ip\":\"1.1.1.1\"}" :
                    route == "/gbk" ? "{\"ip\":\"8.8.8.8\",\"pro\":\"广东省\",\"city\":\"深圳市\"}" :
                    "{\"success\":true,\"ip\":\"8.8.8.8\",\"city\":\"Test City\",\"country\":\"Test\"}";
                Encoding encoding = route == "/gbk" ? Encoding.GetEncoding(936) : Encoding.UTF8;
                byte[] bytes = encoding.GetBytes(body);
                string headers = "HTTP/1.1 " + status + " Test\r\nConnection: close\r\nContent-Type: application/json; charset=" + (route == "/gbk" ? "gbk" : "utf-8") + "\r\nContent-Length: " + bytes.Length + "\r\n" + (route == "/rate" ? "Retry-After: 120\r\n" : "") + "\r\n";
                byte[] head = Encoding.ASCII.GetBytes(headers);
                await stream.WriteAsync(head, 0, head.Length); await stream.WriteAsync(bytes, 0, bytes.Length);
            }
            catch (IOException) { }
            catch (ObjectDisposedException) { }
        }
        public void Dispose() { closed = true; listener.Stop(); }
    }
}
