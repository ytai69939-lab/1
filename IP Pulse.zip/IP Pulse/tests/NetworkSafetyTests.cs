using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IPPulse;

internal static class NetworkSafetyTests
{
    private static Settings Direct() { return new Settings { IpSource = "legacy", ProxyMode = "direct", TimeoutSeconds = 2 }; }
    private const string SafeJson = "{\"success\":true,\"ip\":\"8.8.8.8\",\"city\":\"Safe City\"}";

    internal static async Task Run(Action<bool, string> check)
    {
        await SelectedSourceTests(check);
        await AutomaticLookupTests.Run(check);
        Uri origin = new Uri("https://openai.com/");
        check(NetworkMonitor.AllowedRedirect(origin, new Uri("https://www.openai.com/path"), false), "redirect allows canonical www alias");
        check(!NetworkMonitor.AllowedRedirect(origin, new Uri("http://openai.com/"), false), "redirect blocks HTTPS downgrade before request");
        check(!NetworkMonitor.AllowedRedirect(origin, new Uri("https://openai.com.evil.invalid/"), false), "redirect blocks lookalike host");
        check(!NetworkMonitor.AllowedRedirect(origin, new Uri("https://auth.openai.com/"), false), "redirect does not allow arbitrary subdomains");
        check(!NetworkMonitor.AllowedRedirect(origin, new Uri("https://openai.com:8443/"), false), "redirect blocks port changes");
        check(!NetworkMonitor.AllowedRedirect(origin, new Uri("https://user:secret@openai.com/"), false), "redirect blocks embedded credentials");
        check(!NetworkMonitor.AllowedRedirect(origin, new Uri("https://127.0.0.1/"), false), "redirect blocks loopback target");
        check(!NetworkMonitor.AllowedRedirect(origin, new Uri("https://192.168.1.1/"), false), "redirect blocks private address target");
        check(!NetworkMonitor.AllowedRedirect(origin, new Uri("/relative", UriKind.Relative), false), "redirect policy safely rejects unresolved relative URI");
        using (Server server = new Server(path => new Reply { Body = SafeJson }))
        using (NetworkMonitor production = new NetworkMonitor(Direct()))
        {
            ProbeResult result = await production.ProbeAsync(server.Url, CancellationToken.None);
            check(result.Label == "跳转已阻止" && server.TotalCalls == 0, "production constructor cannot enable HTTP loopback test exception");
        }

        using (Server target = new Server(path => new Reply { Body = SafeJson }))
        using (Server server = new Server(null))
        {
            server.Handler = path => path == "/safe" ? new Reply { Body = SafeJson } :
                new Reply { Status = 302, Headers = "Location: " + target.Url.Replace("127.0.0.1", "localhost") + "target\r\n" };
            using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "blocked", server.Url + "safe"))
            {
                ProbeResult probe = await monitor.ProbeAsync(server.Url + "blocked", CancellationToken.None);
                check(probe.Label == "跳转已阻止" && target.TotalCalls == 0, "cross-host website redirect never reaches target");
                IpResult ip = await monitor.GetIpAsync(CancellationToken.None);
                check(ip.Success && ip.City == "Safe City" && target.TotalCalls == 0, "IP redirect is blocked and trusted fallback still works");
            }
        }
        using (Server server = new Server(null))
        {
            server.Handler = path => path == "/safe" ? new Reply { Body = SafeJson } : new Reply { Status = 302, Headers = "Location: /safe\r\n" };
            using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "relative", server.Url + "safe"))
                check((await monitor.GetIpAsync(CancellationToken.None)).City == "Safe City", "same-origin relative redirect works");
        }
        using (Server server = new Server(path => new Reply { Status = 302, Headers = "Location: /loop\r\n" }))
        using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "loop", server.Url + "unused"))
        {
            ProbeResult result = await monitor.ProbeAsync(server.Url + "loop", CancellationToken.None);
            check(result.Label == "跳转已阻止" && server.TotalCalls == 6, "redirect loop stops after five hops");
        }
        using (Server server = new Server(path => new Reply { Status = 302, Headers = "Location: /slow-hop\r\n", HeadersDelay = 1200 }))
        using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "slow-hop", server.Url + "unused"))
        {
            Stopwatch watch = Stopwatch.StartNew();
            ProbeResult result = await monitor.ProbeAsync(server.Url + "slow-hop", CancellationToken.None);
            check(result.Label == "超时" && watch.ElapsedMilliseconds < 3500, "one timeout budget covers all redirect hops");
        }
        using (Server server = new Server(path => new Reply { Body = SafeJson, BodyDelay = path == "/slow-body" ? 6500 : 0 }))
        using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "slow-body", server.Url + "fallback"))
        {
            Stopwatch watch = Stopwatch.StartNew();
            IpResult result = await monitor.GetIpAsync(CancellationToken.None);
            check(result.Success && result.Source.Contains("备用") && watch.ElapsedMilliseconds < 3500, "stalled body aborts at timeout and switches to fallback");
            await Task.Delay(80);
            check(server.AbortedBodies > 0, "timeout closes underlying body connection");
        }
        using (Server server = new Server(path => new Reply { Body = SafeJson, BodyDelay = path == "/slow-body" ? 6500 : 0 }))
        using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "slow-body", server.Url + "fallback"))
        using (CancellationTokenSource cancellation = new CancellationTokenSource())
        {
            Task<IpResult> pending = monitor.GetIpAsync(cancellation.Token);
            if (await Task.WhenAny(server.BodyStarted.Task, Task.Delay(3000)) != server.BodyStarted.Task) throw new Exception("body fixture did not start");
            Stopwatch watch = Stopwatch.StartNew(); cancellation.Cancel();
            bool cancelled = false;
            try { await pending; } catch (OperationCanceledException) { cancelled = true; }
            check(cancelled && watch.ElapsedMilliseconds < 1000 && server.Calls("/fallback") == 0, "caller cancellation aborts body without starting fallback");
        }
        using (Server server = new Server(null))
        {
            server.Handler = path => path == "/primary" ? new Reply { Body = "{\"ip\":\"" + (server.Calls(path) == 1 ? "1.1.1.1" : "9.9.9.9") + "\"}" } :
                new Reply { Status = 429, Headers = "Retry-After: 86400\r\n" };
            IpLookupState state = new IpLookupState();
            IpResult first, second;
            using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "primary", server.Url + "quota", state)) first = await monitor.GetIpAsync(CancellationToken.None);
            using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "primary", server.Url + "quota", state)) second = await monitor.GetIpAsync(CancellationToken.None);
            check(first.Success && first.RetryAfterSeconds == 0, "fallback 24-hour quota does not delay successful primary");
            check(second.Address == "9.9.9.9" && second.RetryAfterSeconds == 0 && server.Calls("/primary") == 2, "primary detects IP change while fallback waits");
            check(server.Calls("/quota") == 1 && state.Remaining(false) >= 86398, "fallback Retry-After persists across monitor instances");
        }
        using (Server server = new Server(path => path == "/primary" ? new Reply { Status = 429, Headers = "Retry-After: 86400\r\n" } : new Reply { Body = SafeJson }))
        {
            IpLookupState state = new IpLookupState();
            IpResult first, second;
            using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "primary", server.Url + "fallback", state)) first = await monitor.GetIpAsync(CancellationToken.None);
            using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "primary", server.Url + "fallback", state)) second = await monitor.GetIpAsync(CancellationToken.None);
            check(first.Success && first.RetryAfterSeconds > 0 && first.RetryAfterSeconds <= 90, "primary quota leaves fallback eligible after its own interval");
            check(!second.Success && server.TotalCalls == 2 && second.RetryAfterSeconds <= 90, "neither rate-limited provider is hammered during cooldown");
        }
        using (Server server = new Server(path => new Reply { Body = path == "/primary" ? "{\"ip\":\"1.1.1.1\"}" : SafeJson }))
        {
            IpLookupState state = new IpLookupState();
            using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "primary", server.Url + "fallback", state)) await monitor.GetIpAsync(CancellationToken.None);
            using (NetworkMonitor monitor = new NetworkMonitor(Direct(), server.Url + "primary", server.Url + "fallback", state))
            {
                IpResult result = await monitor.GetIpAsync(CancellationToken.None);
                check(result.Address == "1.1.1.1" && result.RetryAfterSeconds == 0 && server.Calls("/fallback") == 1, "mismatched egress cooldown preserves primary polling");
            }
        }
    }

    private static async Task SelectedSourceTests(Action<bool, string> check)
    {
        Settings defaults = new Settings();
        check(defaults.ProxyMode == "custom" && defaults.ProxyAddress == "http://127.0.0.1:7897" && defaults.IpSource == "auto", "location edition uses explicit local proxy and automatic location mode");
        foreach (string source in new[] { "ipwho", "ipsb", "ipapi", "ipapiis" })
        {
            string body = "{\"ip\":\"203.0.113.42\",\"country\":\"Example\",\"country_name\":\"Example\",\"city\":\"Test City\",\"location\":{\"country\":\"Example\",\"city\":\"Test City\"}}";
            IpResult result = NetworkMonitor.ParseSelected(body, source);
            check(result.Success && result.City == "Test City" && result.Protocol == "IPv4" && !result.Source.Contains("备用"), "parse fixed provider " + source);
            check(NetworkMonitor.SourceUrl(source).StartsWith("https://"), "fixed provider uses HTTPS " + source);
        }
        check(NetworkMonitor.ParseSelected("{\"ip\":\"2001:db8::42\"}", "ipwho").Protocol == "IPv6", "selected source identifies IPv6 without coercion");
        bool rejected = false;
        try { NetworkMonitor.ParseSelected("{\"ip\":\"203.0.113.42\",\"error\":true}", "ipapi"); } catch { rejected = true; }
        check(rejected, "provider error payload cannot become successful IP");
        rejected = false;
        try { new Settings { IpSource = "unknown" }.Normalize(); } catch { rejected = true; }
        check(rejected, "invalid source fails closed");
        rejected = false;
        try { Settings.ValidateProxy("https://127.0.0.1:7897"); } catch { rejected = true; }
        check(rejected, "unsupported TLS-to-proxy scheme rejected before requesting");
        Settings selected = new Settings { ProxyMode = "direct", IpSource = "ipwho", TimeoutSeconds = 2 };
        using (Server server = new Server(null))
        {
            server.Handler = path => new Reply { Body = "{\"ip\":\"203.0.113." + (server.Calls(path) == 1 ? "42" : "43") + "\",\"city\":\"Test\"}" };
            using (NetworkMonitor monitor = new NetworkMonitor(selected, server.Url + "selected", server.Url + "unused"))
            {
                IpResult first = await monitor.GetIpAsync(CancellationToken.None), second = await monitor.GetIpAsync(CancellationToken.None);
                check(first.Address != second.Address && server.Calls("/selected") == 2, "next poll observes changed exit without cached IP");
                check(server.Calls("/unused") == 0, "fixed source never queries alternate provider");
            }
        }
        using (Server server = new Server(path => new Reply { Status = 503, Body = "private data" }))
        using (NetworkMonitor monitor = new NetworkMonitor(selected, server.Url + "selected", server.Url + "unused"))
        {
            IpResult result = await monitor.GetIpAsync(CancellationToken.None);
            check(!result.Success && server.Calls("/unused") == 0 && !result.Error.Contains("private data"), "fixed provider error sanitized without fallback");
        }
        using (Server server = new Server(path => new Reply { Status = 429, Headers = "Retry-After: 120\r\n" }))
        {
            IpLookupState state = new IpLookupState();
            using (NetworkMonitor monitor = new NetworkMonitor(selected, server.Url + "selected", server.Url + "unused", state))
                check((await monitor.GetIpAsync(CancellationToken.None)).RetryAfterSeconds >= 119, "fixed provider honors Retry-After");
            using (NetworkMonitor monitor = new NetworkMonitor(selected, server.Url + "selected", server.Url + "unused", state))
                check(!(await monitor.GetIpAsync(CancellationToken.None)).Success && server.TotalCalls == 1, "fixed source cooldown survives monitor replacement");
        }
        using (Server server = new Server(path => new Reply { Status = 503 }))
        using (NetworkMonitor monitor = new NetworkMonitor(new Settings { ProxyMode = "custom", ProxyAddress = server.Url, IpSource = "ipwho", TimeoutSeconds = 2 }))
            check(!(await monitor.GetIpAsync(CancellationToken.None)).Success && server.TotalCalls > 0, "explicit proxy failure stays failed without direct fallback");
        using (Server server = new Server(path => new Reply { Body = SafeJson, BodyDelay = 6500 }))
        using (NetworkMonitor monitor = new NetworkMonitor(selected, server.Url + "selected", server.Url + "unused"))
        using (CancellationTokenSource cancellation = new CancellationTokenSource(100))
        {
            bool cancelled = false;
            try { await monitor.GetIpAsync(cancellation.Token); } catch (OperationCanceledException) { cancelled = true; }
            check(cancelled && server.Calls("/unused") == 0, "fixed source cancellation starts no alternate request");
        }
    }

    private sealed class Reply { public int Status = 200; public string Headers = ""; public string Body = ""; public int HeadersDelay, BodyDelay; }
    private sealed class Server : IDisposable
    {
        private readonly TcpListener listener;
        private readonly Dictionary<string, int> calls = new Dictionary<string, int>();
        private volatile bool closed;
        public Func<string, Reply> Handler;
        public readonly string Url;
        public readonly TaskCompletionSource<bool> BodyStarted = new TaskCompletionSource<bool>();
        public int AbortedBodies;
        public int TotalCalls { get { lock (calls) { int total = 0; foreach (int count in calls.Values) total += count; return total; } } }
        public int Calls(string path) { lock (calls) { int count; return calls.TryGetValue(path, out count) ? count : 0; } }
        public Server(Func<string, Reply> handler)
        {
            Handler = handler; listener = new TcpListener(IPAddress.Loopback, 0); listener.Start();
            Url = "http://127.0.0.1:" + ((IPEndPoint)listener.LocalEndpoint).Port + "/"; Task.Run((Func<Task>)Accept);
        }
        private async Task Accept()
        {
            while (!closed)
                try { Start(await listener.AcceptTcpClientAsync()); }
                catch (ObjectDisposedException) { break; }
                catch (SocketException) { break; }
        }
        private void Start(TcpClient client) { Task.Run(() => Serve(client)); }
        private async Task Serve(TcpClient client)
        {
            using (client)
            try
            {
                NetworkStream stream = client.GetStream();
                StreamReader reader = new StreamReader(stream, Encoding.ASCII, false, 1024, true);
                string line = await reader.ReadLineAsync(); if (line == null) return;
                string path = line.Split(' ')[1]; while (!string.IsNullOrEmpty(await reader.ReadLineAsync())) { }
                lock (calls) { int count; calls.TryGetValue(path, out count); calls[path] = count + 1; }
                Reply reply = Handler(path);
                byte[] body = Encoding.UTF8.GetBytes(reply.Body);
                byte[] headers = Encoding.ASCII.GetBytes("HTTP/1.1 " + reply.Status + " Test\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: " + body.Length + "\r\nConnection: close\r\n" + reply.Headers + "\r\n");
                if (reply.HeadersDelay > 0) await Task.Delay(reply.HeadersDelay);
                await stream.WriteAsync(headers, 0, headers.Length);
                if (reply.BodyDelay > 0)
                {
                    Task<int> disconnect = stream.ReadAsync(new byte[1], 0, 1);
                    BodyStarted.TrySetResult(true);
                    if (await Task.WhenAny(disconnect, Task.Delay(reply.BodyDelay)) == disconnect)
                    {
                        try { await disconnect; } catch (IOException) { }
                        Interlocked.Increment(ref AbortedBodies); return;
                    }
                    ObserveFault(disconnect);
                }
                await stream.WriteAsync(body, 0, body.Length);
            }
            catch (IOException) { }
            catch (ObjectDisposedException) { }
        }
        public void Dispose() { closed = true; listener.Stop(); }
        private static void ObserveFault(Task task) { task.ContinueWith(done => { var observed = done.Exception; }, TaskContinuationOptions.OnlyOnFaulted); }
    }
}
