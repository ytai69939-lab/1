using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using IPPulse;

internal static class AutomaticLookupTests
{
    private static IpResult Ip(string address, string city)
    { return new IpResult { Success = true, Address = address, City = city, CheckedAt = DateTime.Now, Source = "test" }; }

    internal static async Task Run(Action<bool, string> check)
    {
        await ChangedIpAndCache(check);
        await QuotasAndFailures(check);
        await ExactCityAndCancellation(check);
        DateTime time = DateTime.UtcNow;
        AutomaticLookupState cache = new AutomaticLookupState { Clock = delegate { return time; } };
        cache.Store(Ip("2001:db8::42", "IPv6 City"));
        check(cache.City("2001:db8:0:0:0:0:0:42") != null, "city cache canonicalizes equivalent IPv6 spellings");
        time = time.AddHours(6).AddSeconds(1);
        check(cache.City("2001:db8::42") == null, "city cache expires after six hours");
        cache.Store(Ip("203.0.113.42", ""));
        check(cache.City("203.0.113.42") == null, "missing city is not cached as a usable location");
        for (int i = 1; i <= 33; i++) { time = time.AddSeconds(1); cache.Store(Ip("203.0.113." + i, "City")); }
        check(cache.City("203.0.113.1") == null && cache.City("203.0.113.33") != null, "city cache has bounded entries and evicts oldest");
    }

    private static async Task ChangedIpAndCache(Action<bool, string> check)
    {
        AutomaticLookupState state = new AutomaticLookupState();
        int detections = 0, cities = 0, progress = 0;
        string active = "203.0.113.42";
        TaskCompletionSource<bool> geoStarted = new TaskCompletionSource<bool>(), release = new TaskCompletionSource<bool>();
        AutomaticLookup lookup = new AutomaticLookup(state, async delegate(string service, string address, CancellationToken token)
        {
            if (service == "ipsb-ip") { detections++; return Ip(active, null); }
            if (service == "ipsb-geo")
            {
                cities++; geoStarted.TrySetResult(true); await release.Task;
                return Ip(address, address.EndsWith("42") ? "City A" : "City B");
            }
            throw new Exception("Unexpected service");
        });
        Task<IpResult> firstTask = lookup.GetAsync(CancellationToken.None, delegate(IpResult value)
        { progress++; check(value.GeoPending && value.Address == active && string.IsNullOrEmpty(value.City), "new IP is published without old city before geolocation completes"); });
        await geoStarted.Task;
        check(progress == 1 && !firstTask.IsCompleted, "slow geolocation cannot hide freshly observed IP");
        release.SetResult(true);
        IpResult first = await firstTask;
        check(first.City == "City A" && !first.GeoPending, "first IP receives its own city");
        active = "203.0.113.43";
        IpResult second = await lookup.GetAsync(CancellationToken.None, delegate(IpResult value)
        { check(string.IsNullOrEmpty(value.City), "node change clears previous city while new lookup is pending"); });
        check(second.Address == active && second.City == "City B", "new node gets city for its exact current IP");
        IpResult repeat = await lookup.GetAsync(CancellationToken.None, null);
        check(detections == 3 && cities == 2 && repeat.City == "City B", "cached city avoids geo requests but never skips current IP detection");
        check(repeat.Detail.Contains("缓存") && repeat.GeoSource == "test", "cached location keeps source and cache disclosure");
    }

    private static async Task QuotasAndFailures(Action<bool, string> check)
    {
        AutomaticLookupState state = new AutomaticLookupState();
        int currentCalls = 0, geoCalls = 0, limitedCalls = 0;
        string active = "203.0.113.42";
        AutomaticLookup lookup = new AutomaticLookup(state, delegate(string service, string address, CancellationToken token)
        {
            if (service == "ipsb-ip") { currentCalls++; return Task.FromResult(Ip(active, null)); }
            if (service == "ipsb-geo") { geoCalls++; throw new Exception("unavailable"); }
            if (service == "ipwho-geo") { limitedCalls++; throw new IpRateLimitException(86400); }
            throw new Exception("Unexpected service");
        });
        IpResult first = await lookup.GetAsync(CancellationToken.None, null);
        active = "203.0.113.43";
        IpResult second = await lookup.GetAsync(CancellationToken.None, null);
        check(first.Success && second.Success && second.Address == active, "geolocation quota never blocks IP change detection");
        check(currentCalls == 2 && geoCalls == 1 && limitedCalls == 1, "geo cooldown skips only affected services without hammering quota");
        check(second.RetryAfterSeconds == 0 && string.IsNullOrEmpty(second.City) && second.Detail.Contains("IP 已更新"), "city failure cannot turn fresh IP into stale success or old location");

        state = new AutomaticLookupState(); int primaryCalls = 0, fallbackCalls = 0;
        Func<string, string, CancellationToken, Task<IpResult>> request = delegate(string service, string address, CancellationToken token)
        {
            if (service == "ipsb-ip") { primaryCalls++; throw new IpRateLimitException(86400); }
            if (service == "pconline-ip") { fallbackCalls++; return Task.FromResult(Ip("203.0.113." + (40 + fallbackCalls), "Fallback City")); }
            throw new Exception("Unexpected service");
        };
        first = await new AutomaticLookup(state, request).GetAsync(CancellationToken.None, null);
        second = await new AutomaticLookup(state, request).GetAsync(CancellationToken.None, null);
        check(primaryCalls == 1 && fallbackCalls == 2 && first.Address != second.Address, "primary quota leaves fallback detector able to follow node changes across instances");
        check(second.City == "Fallback City" && second.RetryAfterSeconds == 0, "working fallback current IP keeps its location and normal cadence");

        state = new AutomaticLookupState();
        state.Delay("ipsb", 86400); state.Delay("pconline", 120);
        first = await new AutomaticLookup(state, delegate { throw new Exception("No request permitted"); }).GetAsync(CancellationToken.None, null);
        check(!first.Success && first.RetryAfterSeconds >= 119 && first.RetryAfterSeconds <= 120, "all detectors limited schedules earliest eligible provider");
        state = new AutomaticLookupState();
        lookup = new AutomaticLookup(state, delegate { throw new Exception("secret IP must not reach output"); });
        first = await lookup.GetAsync(CancellationToken.None, null);
        check(!first.Success && !first.Error.Contains("secret IP") && first.RetryAfterSeconds >= 29, "failed detectors redact exception body and honor retry delay");
    }

    private static async Task ExactCityAndCancellation(Action<bool, string> check)
    {
        int requests = 0;
        AutomaticLookup lookup = new AutomaticLookup(new AutomaticLookupState(), delegate(string service, string address, CancellationToken token)
        {
            requests++;
            if (service == "ipsb-ip") return Task.FromResult(Ip("203.0.113.42", null));
            check(address == "203.0.113.42", "geo query is explicitly tied to freshly detected IP");
            return Task.FromResult(service == "ipsb-geo" ? Ip("203.0.113.43", "Wrong City") : Ip(address, "Correct City"));
        });
        IpResult result = await lookup.GetAsync(CancellationToken.None, null);
        check(requests == 3 && result.City == "Correct City" && result.Address == "203.0.113.42", "mismatched city response discarded before backup exact-IP lookup");
        lookup = new AutomaticLookup(new AutomaticLookupState(), delegate(string service, string address, CancellationToken token)
        {
            if (service == "ipsb-ip") return Task.FromResult(Ip("2001:db8::42", null));
            return Task.FromResult(Ip("2001:db8:0:0:0:0:0:42", "IPv6 City"));
        });
        result = await lookup.GetAsync(CancellationToken.None, null);
        check(result.City == "IPv6 City" && result.Protocol == "IPv6", "exact city matching uses IPv6 address value rather than string spelling");
        requests = 0;
        lookup = new AutomaticLookup(new AutomaticLookupState(), delegate(string service, string address, CancellationToken token)
        {
            requests++; return Task.FromResult(Ip("203.0.113.42", null));
        });
        using (CancellationTokenSource cancellation = new CancellationTokenSource())
        {
            bool cancelled = false;
            try { await lookup.GetAsync(cancellation.Token, delegate { cancellation.Cancel(); }); }
            catch (OperationCanceledException) { cancelled = true; }
            check(cancelled && requests == 1, "cancelled IP cycle starts no geolocation or alternate request");
        }
        lookup = new AutomaticLookup(new AutomaticLookupState(), delegate(string service, string address, CancellationToken token)
        {
            IpResult value = Ip("203.0.113.42", null);
            if (service == "ipsb-geo") { value.Country = "Example"; value.Region = "State"; }
            return Task.FromResult(value);
        });
        result = await lookup.GetAsync(CancellationToken.None, null);
        check(result.Country == "Example" && result.Region == "State" && string.IsNullOrEmpty(result.City), "missing city preserves only verified partial location for current IP");
        check(!result.GeoPending, "exhausted city sources finish with explicit non-pending state");
    }
}
