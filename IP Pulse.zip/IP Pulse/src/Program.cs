using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using Forms = System.Windows.Forms;

[assembly: AssemblyTitle("IP Pulse")]
[assembly: AssemblyProduct("IP Pulse")]
[assembly: AssemblyDescription("公网 IP、城市与 OpenAI / ChatGPT HTTPS 监视器")]
[assembly: AssemblyVersion("1.2.5.0")]

namespace IPPulse
{
    internal static class Program
    {
        [STAThread]
        public static int Main(string[] args)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            ServicePointManager.DefaultConnectionLimit = 12;
            string root = AppDomain.CurrentDomain.BaseDirectory;
            string settingsPath = Path.Combine(root, "settings.json");
            try
            {
                if (args.Contains("--traffic-probe"))
                {
                    Settings settings = Settings.Load(settingsPath);
                    TrafficMonitor traffic = new TrafficMonitor();
                    traffic.Read(settings.TrafficAdapterId);
                    Task.Delay(1250).GetAwaiter().GetResult();
                    TrafficResult result = traffic.Read(settings.TrafficAdapterId);
                    WriteJson(Argument(args, "--output") ?? Path.Combine(root, "traffic-result.json"), result);
                    return result.Ready ? 0 : 2;
                }
                if (args.Contains("--probe"))
                {
                    string output = Argument(args, "--output") ?? Path.Combine(root, "probe-result.json");
                    Settings settings = Settings.Load(settingsPath);
                    using (NetworkMonitor monitor = new NetworkMonitor(settings))
                    {
                        Task<IpResult> ip = monitor.GetIpAsync(CancellationToken.None);
                        Task<ProbeResult> openai = monitor.ProbeAsync("https://openai.com/", CancellationToken.None);
                        Task<ProbeResult> gpt = monitor.ProbeAsync("https://chatgpt.com/", CancellationToken.None);
                        Task.WhenAll(ip, (Task)openai, gpt).GetAwaiter().GetResult();
                        WriteJson(output, new { Ip = new { Success = ip.Result.Success, Protocol = ip.Result.Protocol, Source = ip.Result.Source,
                            RetryAfterSeconds = ip.Result.RetryAfterSeconds }, OpenAI = openai.Result, ChatGPT = gpt.Result, ProxyMode = settings.ProxyMode,
                            Note = "网页 HTTPS 响应头耗时，不代表模型生成延迟或账号可用性。" });
                        return ip.Result.Success ? 0 : 2;
                    }
                }
                Application app = new Application { ShutdownMode = ShutdownMode.OnMainWindowClose };
                if (args.Contains("--preview") || args.Contains("--preview-compact") || args.Contains("--preview-settings"))
                {
                    Widget preview = new Widget(new Settings(), settingsPath, true);
                    app.MainWindow = preview.Window;
                    preview.Window.Show();
                    preview.RenderPreview(Argument(args, "--output") ?? Path.Combine(root, "preview.png"), args.Contains("--preview-compact"), args.Contains("--preview-settings"), args.Contains("--long-values"), Argument(args, "--preview-state"));
                    preview.Window.Close();
                    return 0;
                }
                bool first;
                using (Mutex mutex = new Mutex(true, "Local\\IPPulse.CompactLayout.Desktop.v1", out first))
                using (EventWaitHandle wake = new EventWaitHandle(false, EventResetMode.AutoReset, "Local\\IPPulse.CompactLayout.Wake.v1"))
                {
                    if (!first) { wake.Set(); return 0; }
                    Settings settings = Settings.Load(settingsPath);
                    using (Widget widget = new Widget(settings, settingsPath, false))
                    {
                        app.MainWindow = widget.Window;
                        RegisteredWaitHandle registration = ThreadPool.RegisterWaitForSingleObject(wake,
                            delegate { if (!widget.IsClosing) app.Dispatcher.BeginInvoke(new Action(widget.Restore)); }, null, -1, false);
                        app.DispatcherUnhandledException += delegate(object sender, DispatcherUnhandledExceptionEventArgs e)
                        {
                            e.Handled = true;
                            MessageBox.Show(widget.Window, e.Exception.Message, "IP Pulse", MessageBoxButton.OK, MessageBoxImage.Warning);
                        };
                        try { app.Run(widget.Window); }
                        finally { registration.Unregister(null); }
                    }
                    mutex.ReleaseMutex();
                }
                return 0;
            }
            catch (Exception ex)
            {
                string output = Argument(args, "--output");
                if (output != null) { try { WriteJson(output, new { Error = "操作失败，请检查设置或输出路径。诊断不保存异常原文。" }); } catch { } }
                else MessageBox.Show(ex.Message, "IP Pulse 启动失败", MessageBoxButton.OK, MessageBoxImage.Error);
                return 1;
            }
        }

        private static string Argument(string[] args, string name)
        {
            int index = Array.IndexOf(args, name);
            return index >= 0 && index + 1 < args.Length ? args[index + 1] : null;
        }

        internal static void WriteJson(string path, object value)
        { File.WriteAllText(path, new JavaScriptSerializer().Serialize(value), new UTF8Encoding(false)); }
    }

    internal sealed class Widget : IDisposable
    {
        public readonly Window Window;
        public bool IsClosing { get; private set; }
        private Settings settings;
        private readonly string settingsPath;
        private readonly bool preview;
        private readonly DispatcherTimer timer;
        private readonly DispatcherTimer networkDebounce;
        private readonly Forms.NotifyIcon tray;
        private CancellationTokenSource cycle;
        private int generation;
        private bool ipBusy, openAiBusy, gptBusy;
        private DateTime ipDue = DateTime.MinValue, openAiDue = DateTime.MinValue, gptDue = DateTime.MinValue;
        private DateTime lastIpTime = DateTime.MinValue;
        private string lastIp;
        private string lastLocation = "正在查询城市";
        private string openAiSummary = "—", gptSummary = "—";
        private string openAiBrief = "—", gptBrief = "—";
        private bool compact;
        private bool ipStale;
        private int ipRetryDelay;
        private Point? dragStart;
        private bool disposed;
        private readonly TrafficMonitor trafficMonitor = new TrafficMonitor();
        private AdapterReading[] trafficAdapters = new AdapterReading[0];
        private bool trafficBusy;

        public Widget(Settings initial, string path, bool isPreview)
        {
            settings = initial;
            settingsPath = path;
            preview = isPreview;
            Window = LoadWindow("Widget.xaml");
            using (Stream iconStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("IP-Pulse.ico"))
            {
                IconBitmapDecoder decoder = new IconBitmapDecoder(iconStream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
                Window.Icon = decoder.Frames.First(frame => frame.PixelWidth == 32);
            }
            Get<Image>("AppIcon").Source = Window.Icon;
            Window.Topmost = settings.Topmost;
            compact = settings.Compact;
            timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += delegate { Poll(); UpdateFooter(); UpdateTrafficAsync(); };
            networkDebounce = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };
            networkDebounce.Tick += delegate { networkDebounce.Stop(); Refresh(); };
            cycle = new CancellationTokenSource();
            if (!preview)
            {
                System.Drawing.Icon trayImage;
                using (Stream iconStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("IP-Pulse.ico"))
                using (System.Drawing.Icon icon = new System.Drawing.Icon(iconStream, Forms.SystemInformation.SmallIconSize))
                    trayImage = (System.Drawing.Icon)icon.Clone();
                tray = new Forms.NotifyIcon { Icon = trayImage,
                    Text = "IP Pulse · 网络状态", Visible = true };
                Forms.ContextMenuStrip menu = new Forms.ContextMenuStrip();
                menu.Items.Add("显示 / 展开", null, delegate { Dispatch(Restore); });
                menu.Items.Add("立即刷新", null, delegate { Dispatch(Refresh); });
                menu.Items.Add("设置", null, delegate { Dispatch(OpenSettings); });
                menu.Items.Add(new Forms.ToolStripSeparator());
                menu.Items.Add("退出", null, delegate { Dispatch(delegate { Window.Close(); }); });
                tray.ContextMenuStrip = menu;
                tray.DoubleClick += delegate { Dispatch(Restore); };
                NetworkChange.NetworkAddressChanged += OnNetworkChanged;
                NetworkChange.NetworkAvailabilityChanged += OnAvailabilityChanged;
            }
            Get<Button>("CompactButton").Click += delegate { SetCompact(true); };
            Get<Button>("HideButton").Click += delegate { Window.Hide(); };
            Get<Button>("RefreshButton").Click += delegate { Refresh(); };
            Get<Button>("SettingsButton").Click += delegate { OpenSettings(); };
            Get<Button>("CopyButton").Click += delegate
            {
                if (lastIp == null) return;
                try { Clipboard.SetText(lastIp); Notify("已复制 IP", lastIp); }
                catch (Exception ex) { Notify("复制失败", ex.Message); }
            };
            Get<Grid>("DragHeader").MouseLeftButtonDown += HeaderDrag;
            Border mini = Get<Border>("CompactCard");
            mini.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e)
            {
                dragStart = new Point(Window.Left, Window.Top);
                try { Window.DragMove(); } catch (InvalidOperationException) { }
                bool moved = dragStart.HasValue && (Math.Abs(Window.Left - dragStart.Value.X) > 3 || Math.Abs(Window.Top - dragStart.Value.Y) > 3);
                Clamp();
                if (!moved) SetCompact(false); else SaveSettingsQuietly();
                e.Handled = true;
            };
            Window.ContextMenu = BuildContextMenu();
            Window.Loaded += delegate
            {
                ApplyCompact();
                if (!double.IsNaN(settings.Left) && settings.Left > -90000 && !double.IsNaN(settings.Top) && settings.Top > -90000)
                { Window.Left = settings.Left; Window.Top = settings.Top; }
                else
                { Window.Left = SystemParameters.WorkArea.Right - Window.Width - 24; Window.Top = SystemParameters.WorkArea.Bottom - Window.Height - 24; }
                Clamp();
                if (!preview) { timer.Start(); Poll(); UpdateTrafficAsync(); }
            };
            Window.Closing += delegate { IsClosing = true; SaveSettingsQuietly(); Dispose(); };
            Window.PreviewKeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.Key == Key.F5) { Refresh(); e.Handled = true; }
                if (e.Key == Key.Escape) { SetCompact(true); e.Handled = true; }
            };
        }

        private static Window LoadWindow(string resource)
        {
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource))
                return (Window)XamlReader.Load(stream);
        }
        private T Get<T>(string name) where T : class { return Window.FindName(name) as T; }
        private void Text(string name, string value) { Get<TextBlock>(name).Text = value; }
        private static Brush Color(string value) { return (Brush)new BrushConverter().ConvertFromString(value); }
        private void Dispatch(Action action) { if (!IsClosing) Window.Dispatcher.BeginInvoke(action); }
        private ContextMenu BuildContextMenu()
        {
            ContextMenu menu = new ContextMenu();
            AddMenu(menu, "展开 / 迷你条", delegate { SetCompact(!compact); });
            AddMenu(menu, "立即刷新 (F5)", Refresh);
            AddMenu(menu, "复制公网 IP", delegate { if (lastIp != null) Clipboard.SetText(lastIp); });
            AddMenu(menu, "设置", OpenSettings);
            AddMenu(menu, "隐藏到托盘", delegate { Window.Hide(); });
            menu.Items.Add(new Separator());
            AddMenu(menu, "退出", delegate { Window.Close(); });
            return menu;
        }
        private static void AddMenu(ContextMenu menu, string label, Action action)
        { MenuItem item = new MenuItem { Header = label }; item.Click += delegate { action(); }; menu.Items.Add(item); }

        private void HeaderDrag(object sender, MouseButtonEventArgs e)
        {
            DependencyObject source = e.OriginalSource as DependencyObject;
            while (source != null)
            { if (source is Button) return; source = VisualTreeHelper.GetParent(source); }
            try { Window.DragMove(); } catch (InvalidOperationException) { }
            Clamp(); SaveSettingsQuietly();
        }

        private void Clamp()
        {
            // Screen.FromHandle handles a secondary display and its taskbar. Convert physical pixels to WPF DIPs.
            IntPtr handle = new WindowInteropHelper(Window).Handle;
            System.Drawing.Rectangle work = Forms.Screen.FromHandle(handle).WorkingArea;
            PresentationSource source = PresentationSource.FromVisual(Window);
            Matrix transform = source == null ? Matrix.Identity : source.CompositionTarget.TransformFromDevice;
            Point a = transform.Transform(new Point(work.Left, work.Top));
            Point b = transform.Transform(new Point(work.Right, work.Bottom));
            Window.Left = Math.Max(a.X, Math.Min(Window.Left, b.X - Window.Width));
            Window.Top = Math.Max(a.Y, Math.Min(Window.Top, b.Y - Window.Height));
        }

        private void ApplyCompact()
        {
            Get<Border>("FullCard").Visibility = compact ? Visibility.Collapsed : Visibility.Visible;
            Get<Border>("CompactCard").Visibility = compact ? Visibility.Visible : Visibility.Collapsed;
            Window.Width = compact ? 340 : 410;
            Window.Height = compact ? 68 : 174;
        }
        private void SetCompact(bool value)
        { compact = value; settings.Compact = value; ApplyCompact(); Clamp(); SaveSettingsQuietly(); }
        public void Restore()
        { if (IsClosing) return; Window.Show(); SetCompact(false); Window.Activate(); }

        private async void UpdateTrafficAsync()
        {
            if (IsClosing || preview || trafficBusy) return;
            trafficBusy = true;
            string adapterId = settings.TrafficAdapterId;
            try
            {
                TrafficResult result = await Task.Run(delegate { return trafficMonitor.Read(adapterId); });
                if (!IsClosing && settings.TrafficAdapterId == adapterId) ApplyTraffic(result);
            }
            catch (Exception ex)
            {
                if (!IsClosing && settings.TrafficAdapterId == adapterId) ApplyTraffic(new TrafficResult { Message = "网速读取失败：" + ex.Message });
            }
            finally { trafficBusy = false; }
        }

        private void ApplyTraffic(TrafficResult result)
        {
            trafficAdapters = result.Adapters;
            string download = result.Ready ? TrafficMonitor.FormatRate(result.DownloadBytesPerSecond) : "—";
            string upload = result.Ready ? TrafficMonitor.FormatRate(result.UploadBytesPerSecond) : "—";
            Text("DownloadText", download); Text("UploadText", upload);
            Text("MiniDownloadText", "↓ " + download); Text("MiniUploadText", "↑ " + upload);
            Text("TrafficAdapterText", result.AdapterName == null ? result.Message : result.AdapterName + (result.Ready ? "" : " · " + result.Message));
            string detail = (result.AdapterName == null ? "" : "统计网卡：" + result.AdapterName + "\n") + result.Message +
                "\n每秒采样；显示本机该网卡全部程序的收发，包含局域网流量。\n不叠加物理网卡与 VPN/TUN；不是宽带测速，也不是共享出口总流量。";
            foreach (string name in new[] { "DownloadText", "UploadText", "TrafficAdapterText", "MiniDownloadText", "MiniUploadText" }) Get<TextBlock>(name).ToolTip = detail;
        }

        private void OnNetworkChanged(object sender, EventArgs e) { Dispatch(ScheduleNetworkRefresh); }
        private void OnAvailabilityChanged(object sender, NetworkAvailabilityEventArgs e) { Dispatch(ScheduleNetworkRefresh); }
        private void ScheduleNetworkRefresh() { networkDebounce.Stop(); networkDebounce.Start(); }

        private void Refresh()
        {
            if (IsClosing || preview) return;
            generation++;
            cycle.Cancel(); cycle.Dispose(); cycle = new CancellationTokenSource();
            ipBusy = openAiBusy = gptBusy = false;
            ipDue = openAiDue = gptDue = DateTime.MinValue;
            ApplyIp(new IpResult { Error = "正在重新验证，旧值仅供参考" });
            Text("UpdateText", "正在刷新…");
            Poll();
        }

        private void Poll()
        {
            if (IsClosing || preview) return;
            DateTime now = DateTime.Now;
            if (!ipBusy && now >= ipDue) { ipBusy = true; FetchIp(generation, cycle.Token); }
            if (!openAiBusy && now >= openAiDue) { openAiBusy = true; FetchProbe(true, generation, cycle.Token); }
            if (!gptBusy && now >= gptDue) { gptBusy = true; FetchProbe(false, generation, cycle.Token); }
        }

        private async void FetchIp(int version, CancellationToken token)
        {
            try
            {
                IpResult result;
                // Proxy auto-detection may block synchronously; keep the entire request setup off the UI thread.
                Settings snapshot = Snapshot();
                result = await Task.Run(async delegate
                {
                    using (NetworkMonitor monitor = new NetworkMonitor(snapshot))
                        return await monitor.GetIpAsync(token, delegate(IpResult verified)
                        {
                            Dispatch(delegate { if (!IsClosing && version == generation && !token.IsCancellationRequested) ApplyIp(verified); });
                        }).ConfigureAwait(false);
                }, token);
                if (IsClosing || version != generation) return;
                ApplyIp(result);
                ipRetryDelay = result.RetryAfterSeconds;
            }
            catch (OperationCanceledException) { }
            catch (Exception ex) { if (!IsClosing && version == generation) ApplyIp(new IpResult { Error = ex.Message }); }
            finally
            {
                if (!IsClosing && version == generation)
                { ipBusy = false; ipDue = DateTime.Now.AddSeconds(Math.Max(ipRetryDelay, ipStale ? Math.Max(30, settings.IntervalSeconds) : settings.IntervalSeconds)); UpdateFooter(); }
            }
        }

        private async void FetchProbe(bool isOpenAi, int version, CancellationToken token)
        {
            int delay = settings.IntervalSeconds;
            try
            {
                Settings snapshot = Snapshot();
                ProbeResult result = await Task.Run(async delegate
                {
                    using (NetworkMonitor monitor = new NetworkMonitor(snapshot))
                        return await monitor.ProbeAsync(isOpenAi ? "https://openai.com/" : "https://chatgpt.com/", token).ConfigureAwait(false);
                }, token);
                if (IsClosing || version != generation) return;
                if (result.State != "ok") delay = Math.Max(30, delay);
                if (result.HttpStatus == 429) delay = Math.Max(60, delay);
                delay = Math.Max(delay, result.RetryAfterSeconds);
                ApplyProbe(isOpenAi, result);
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                if (!IsClosing && version == generation) ApplyProbe(isOpenAi, new ProbeResult { State = "offline", Label = "检测失败", Detail = ex.Message });
            }
            finally
            {
                if (!IsClosing && version == generation)
                {
                    if (isOpenAi) { openAiBusy = false; openAiDue = DateTime.Now.AddSeconds(delay); }
                    else { gptBusy = false; gptDue = DateTime.Now.AddSeconds(delay); }
                    UpdateFooter();
                }
            }
        }

        private Settings Snapshot()
        {
            return new Settings { IntervalSeconds = settings.IntervalSeconds, TimeoutSeconds = settings.TimeoutSeconds,
                ProxyMode = settings.ProxyMode, ProxyAddress = settings.ProxyAddress, IpSource = settings.IpSource };
        }

        private void ApplyIp(IpResult result)
        {
            ipStale = !result.Success;
            if (result.Success)
            {
                string previous = lastIp;
                lastIp = result.Address;
                lastLocation = result.GeoPending ? "归属地查询中…" : result.Location;
                if (!result.GeoPending && string.IsNullOrWhiteSpace(result.City) && !lastLocation.Contains("城市未知")) lastLocation += " · 城市未知";
                lastIpTime = result.CheckedAt;
                Text("IpText", lastIp); Text("CityText", lastLocation);
                bool wrapIp = lastIp.Contains(":") && lastIp.Length > 24;
                Get<TextBlock>("IpText").TextWrapping = wrapIp ? TextWrapping.Wrap : TextWrapping.NoWrap;
                Get<TextBlock>("IpText").FontSize = wrapIp ? 15 : lastIp.Length > 19 ? 17 : lastIp.Length > 15 ? 21 : lastIp.Length > 13 ? 27 : 30;
                Get<TextBlock>("IpText").LineHeight = wrapIp ? 17 : double.NaN;
                Get<TextBlock>("IpText").LineStackingStrategy = wrapIp ? LineStackingStrategy.BlockLineHeight : LineStackingStrategy.MaxHeight;
                if (wrapIp)
                {
                    int split = lastIp.LastIndexOf(':', lastIp.Length / 2);
                    if (split >= 0) Text("IpText", lastIp.Insert(split + 1, "\n"));
                }
                Text("ProviderText", result.Protocol + " · " + result.Source + (result.GeoPending ? " · 查询城市" :
                    string.IsNullOrWhiteSpace(result.GeoSource) ? "" : " · 城市 " + result.GeoSource));
                Get<TextBlock>("ProviderText").ToolTip = "协议：" + result.Protocol + "\nIP 来源：" + result.Source +
                    "\n城市来源：" + (result.GeoSource ?? result.Source) + "\n" + result.Detail + "\n接口描述：" + result.Isp +
                    "\n城市是 IP 数据库估计。比较时应使用相同来源、协议和代理路径。";
                if (previous != null && previous != lastIp && settings.NotifyIpChanges) Notify("公网 IP 已变化", previous + " → " + lastIp + "\n" + lastLocation);
                if (tray != null) tray.Text = ("IP Pulse · " + lastIp).Substring(0, Math.Min(63, ("IP Pulse · " + lastIp).Length));
            }
            else
            {
                Text("IpText", lastIp ?? "获取失败");
                Text("CityText", lastIp == null ? "请检查网络或代理设置" : lastLocation + "（上次结果）");
                Text("ProviderText", "查询失败 · " + (lastIpTime == DateTime.MinValue ? "暂无历史结果" : "上次成功 " + lastIpTime.ToString("HH:mm:ss")));
                Get<TextBlock>("ProviderText").ToolTip = result.Error;
            }
            Get<TextBlock>("IpText").Foreground = Color(ipStale ? "#F3BB6C" : "#EDF2FA");
            Get<TextBlock>("IpText").ToolTip = lastIp == null ? result.Error : lastIp + (ipStale ? "\n上次结果，当前未验证" : "\n本次查询接口所见的出口 IP");
            Text("MiniIp", (lastIp ?? "IP 获取失败") + (ipStale && lastIp != null ? " *" : ""));
            int miniLength = (lastIp ?? "").Length + (ipStale && lastIp != null ? 2 : 0);
            Get<TextBlock>("MiniIp").FontSize = miniLength > 20 ? 14 : miniLength > 17 ? 16 : 18;
            Get<TextBlock>("MiniIp").ToolTip = lastIp == null ? result.Error : lastIp + (ipStale ? "\n上次结果，当前未验证" : "\n本次查询接口所见的出口 IP");
            Text("MiniCity", lastLocation + (ipStale ? " · 未更新" : ""));
            Get<TextBlock>("CityText").ToolTip = lastLocation;
            Get<TextBlock>("MiniCity").ToolTip = lastLocation;
            Get<TextBlock>("MiniIp").Foreground = Color(ipStale ? "#F3BB6C" : "#EDF2FA");
            Text("UpdateText", "IP 查询于 " + DateTime.Now.ToString("HH:mm:ss"));
        }

        private void ApplyProbe(bool isOpenAi, ProbeResult result)
        {
            string prefix = isOpenAi ? "OpenAi" : "Gpt";
            string color = result.State == "ok" ? "#59E1C0" : result.State == "limited" ? "#F3BB6C" : "#FF8790";
            Text(prefix + "Latency", result.Milliseconds.HasValue ? result.Milliseconds + " ms" : "— ms");
            Text(prefix + "Status", result.Label);
            Get<TextBlock>(prefix + "Latency").Foreground = Color(color);
            Get<TextBlock>(prefix + "Status").Foreground = Color(color);
            string detail = (result.CheckedAt == DateTime.MinValue ? DateTime.Now : result.CheckedAt).ToString("HH:mm:ss") + "\n" + result.Detail;
            Get<TextBlock>(prefix + "Latency").ToolTip = detail;
            Get<TextBlock>(prefix + "Status").ToolTip = detail;
            string summary = result.State == "ok" ? result.Milliseconds + "ms" :
                (result.HttpStatus.HasValue ? result.HttpStatus + "·" : result.Label) + (result.Milliseconds.HasValue ? result.Milliseconds + "ms" : "");
            if (isOpenAi) { openAiSummary = summary; openAiBrief = BriefProbe(result); }
            else { gptSummary = summary; gptBrief = BriefProbe(result); }
            // Both latencies remain visible in compact mode, including a blocked response's latency.
            Text("MiniStatus", "OAI " + openAiBrief + " / GPT " + gptBrief);
            Get<TextBlock>("MiniStatus").ToolTip = "OpenAI " + openAiSummary + "\nChatGPT " + gptSummary;
            Text("UpdateText", "网站检测于 " + DateTime.Now.ToString("HH:mm:ss"));
        }

        private static string BriefProbe(ProbeResult result)
        {
            if (!result.Milliseconds.HasValue) return result.Label;
            long milliseconds = result.Milliseconds.Value;
            string time = milliseconds >= 1000 ? (milliseconds / 1000d).ToString("0.#", CultureInfo.InvariantCulture) + "s" : milliseconds + "ms";
            return result.State == "ok" ? time : (result.HttpStatus.HasValue ? result.HttpStatus + "·" : result.Label + "·") + time;
        }

        private void UpdateFooter()
        {
            string route = settings.ProxyMode == "direct" ? "直接连接" : settings.ProxyMode == "custom" ? "指定代理" : "系统代理";
            Text("RouteText", route + " · " + settings.IntervalSeconds + "s");
            Get<TextBlock>("RouteText").ToolTip = route + (settings.ProxyMode == "custom" ? "：" + settings.ProxyAddress : "") +
                "\nIP 来源：" + NetworkMonitor.SourceName(settings.IpSource) + " · 每 " + settings.IntervalSeconds + " 秒" +
                (ipRetryDelay > settings.IntervalSeconds ? " · IP 降频 " + ipRetryDelay + "s" : " · 异常时按服务降频重试") +
                "\n此处是查询服务所见的出口；各网站可因分流或服务端策略使用不同出口。";
            if (ipRetryDelay > settings.IntervalSeconds && !ipBusy)
                Text("UpdateText", "IP 待重试 " + Math.Max(0, (int)Math.Ceiling((ipDue - DateTime.Now).TotalSeconds)) +
                    "s · 上次成功 " + (lastIpTime == DateTime.MinValue ? "—" : lastIpTime.ToString("HH:mm:ss")));
            else if (ipBusy || openAiBusy || gptBusy) Text("UpdateText", "检测中" + (ipBusy ? " · IP / 城市" : "") + (openAiBusy ? " · OpenAI" : "") + (gptBusy ? " · ChatGPT" : ""));
            else
            {
                DateTime due = new[] { ipDue, openAiDue, gptDue }.Min();
                Text("UpdateText", "IP 更新 " + (lastIpTime == DateTime.MinValue ? "—" : lastIpTime.ToString("HH:mm:ss")) + " · " + Math.Max(0, (int)Math.Ceiling((due - DateTime.Now).TotalSeconds)) + " 秒后检测");
            }
        }

        public void Notify(string title, string body)
        { if (tray != null && !IsClosing) { tray.BalloonTipTitle = title; tray.BalloonTipText = body; tray.ShowBalloonTip(3500); } }

        private static void SelectTag(ComboBox box, object value)
        {
            foreach (ComboBoxItem item in box.Items) if (Convert.ToString(item.Tag) == Convert.ToString(value)) { box.SelectedItem = item; return; }
            ComboBoxItem custom = new ComboBoxItem { Content = value + " 秒", Tag = Convert.ToString(value) };
            box.Items.Add(custom); box.SelectedItem = custom;
        }
        private static string Tag(ComboBox box) { return Convert.ToString(((ComboBoxItem)box.SelectedItem).Tag); }

        private void OpenSettings()
        {
            if (IsClosing || preview) return;
            CreateSettingsWindow().ShowDialog();
        }

        private Window CreateSettingsWindow()
        {
            Window dialog = LoadWindow("Settings.xaml");
            dialog.Icon = Window.Icon;
            dialog.Owner = Window; dialog.Topmost = Window.Topmost;
            ComboBox interval = (ComboBox)dialog.FindName("Interval"), timeout = (ComboBox)dialog.FindName("Timeout"), proxy = (ComboBox)dialog.FindName("ProxyMode");
            ComboBox source = (ComboBox)dialog.FindName("IpSource");
            SelectTag(source, settings.IpSource);
            ComboBox adapter = (ComboBox)dialog.FindName("TrafficAdapter");
            adapter.Items.Add(new ComboBoxItem { Content = "自动选择（优先联网物理网卡）", Tag = "" });
            foreach (AdapterReading reading in trafficAdapters)
                adapter.Items.Add(new ComboBoxItem { Content = reading.Name + (reading.IsUp ? "" : "（已断开）"), Tag = reading.Id, ToolTip = reading.Description });
            string selectedAdapter = settings.TrafficAdapterId ?? "";
            if (selectedAdapter != "" && !trafficAdapters.Any(reading => reading.Id == selectedAdapter))
                adapter.Items.Add(new ComboBoxItem { Content = "上次选择的网卡（暂不可用）", Tag = selectedAdapter });
            SelectTag(adapter, selectedAdapter);
            TextBox address = (TextBox)dialog.FindName("ProxyAddress");
            CheckBox top = (CheckBox)dialog.FindName("AlwaysOnTop"), notify = (CheckBox)dialog.FindName("IpNotification"), auto = (CheckBox)dialog.FindName("AutoStart");
            SelectTag(interval, settings.IntervalSeconds); SelectTag(timeout, settings.TimeoutSeconds); SelectTag(proxy, settings.ProxyMode);
            address.Text = settings.ProxyAddress; address.IsEnabled = settings.ProxyMode == "custom";
            proxy.SelectionChanged += delegate { address.IsEnabled = Tag(proxy) == "custom"; };
            top.IsChecked = settings.Topmost; notify.IsChecked = settings.NotifyIpChanges;
            bool wasAuto = !preview && IsAutoStart(); auto.IsChecked = wasAuto;
            ((Button)dialog.FindName("Cancel")).Click += delegate { dialog.Close(); };
            ((Button)dialog.FindName("Save")).Click += delegate
            {
                if (preview) return;
                try
                {
                    Settings changed = new Settings { IntervalSeconds = int.Parse(Tag(interval)), TimeoutSeconds = int.Parse(Tag(timeout)),
                        ProxyMode = Tag(proxy), ProxyAddress = address.Text.Trim(), IpSource = Tag(source), Topmost = top.IsChecked == true,
                        NotifyIpChanges = notify.IsChecked == true, Compact = compact, Left = Window.Left, Top = Window.Top, TrafficAdapterId = Tag(adapter) };
                    changed.Normalize();
                    changed.Save(settingsPath);
                    if (changed.IpSource != settings.IpSource || changed.ProxyMode != settings.ProxyMode || changed.ProxyAddress != settings.ProxyAddress)
                    { lastIp = null; lastIpTime = DateTime.MinValue; lastLocation = "正在重新查询"; }
                    settings = changed; Window.Topmost = changed.Topmost;
                    if (auto.IsChecked == true != wasAuto) SetAutoStart(auto.IsChecked == true);
                    dialog.Close(); Refresh();
                }
                catch (Exception ex) { MessageBox.Show(dialog, ex.Message, "设置未完全保存", MessageBoxButton.OK, MessageBoxImage.Warning); }
            };
            return dialog;
        }

        private bool IsAutoStart()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))
                    return key != null && Convert.ToString(key.GetValue("IPPulseCompactLayout")) == "\"" + Assembly.GetExecutingAssembly().Location + "\"";
            }
            catch { return false; }
        }
        private void SetAutoStart(bool enabled)
        {
            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))
            { if (enabled) key.SetValue("IPPulseCompactLayout", "\"" + Assembly.GetExecutingAssembly().Location + "\""); else key.DeleteValue("IPPulseCompactLayout", false); }
        }

        private void SaveSettingsQuietly()
        {
            if (preview) return;
            try { settings.Left = Window.Left; settings.Top = Window.Top; settings.Compact = compact; settings.Save(settingsPath); }
            catch (Exception ex) { if (!IsClosing) Notify("配置保存失败", ex.Message + "\n请将程序放在有写权限的文件夹。"); }
        }

        internal void RenderPreview(string output, bool mini, bool showSettings, bool longValues, string state)
        {
            ApplyIp(new IpResult { Success = true, Address = longValues ? "2606:4700:4700:1111:abcd:ef01:2345:6789" : "203.0.113.42", City = "示例城市", Region = "示例地区", Source = "演示数据", GeoSource = "示例数据库", Isp = "界面预览，非实际查询结果", CheckedAt = DateTime.Now });
            ApplyProbe(true, NetworkMonitor.Classify("https://openai.com/", "https://openai.com/", longValues ? 407 : 200, longValues ? 20000 : 182, false));
            ApplyProbe(false, NetworkMonitor.Classify("https://chatgpt.com/", "https://chatgpt.com/", longValues ? 503 : 403, longValues ? 20000 : 236, false));
            ApplyTraffic(new TrafficResult { Ready = true, AdapterName = "示例以太网", Message = "示例数据", DownloadBytesPerSecond = (longValues ? 1023.9 : 18.7) * 1024 * 1024, UploadBytesPerSecond = (longValues ? 1023.9 : 2.3) * 1024 * 1024,
                Adapters = new[] { new AdapterReading { Id = "sample", Name = "示例以太网", IsUp = true, IsHardware = true } } });
            Text("RouteText", "演示数据 · 10s");
            if (state == "layout" || state == "layout-longcity")
                ApplyIp(new IpResult { Success = true, Address = longValues ? "2606:4700:4700:1111:abcd:ef01:2345:6789" : "198.51.100.254",
                    Country = "United States", Region = "California", City = state == "layout-longcity" ? "San Francisco Bay Metropolitan Area" : "Los Angeles",
                    Source = "演示数据", CheckedAt = DateTime.Now });
            if (state == "pending")
                ApplyIp(new IpResult { Success = true, Address = "203.0.113.43", Source = "IP.SB（示例）", GeoPending = true, CheckedAt = DateTime.Now });
            if (state == "partial")
                ApplyIp(new IpResult { Success = true, Address = "203.0.113.43", Country = "示例国家", Region = "示例地区", Source = "IP.SB（示例）", CheckedAt = DateTime.Now });
            if (state == "stale")
            {
                ApplyIp(new IpResult { Error = "示例：所有 IP 检测服务暂不可用" });
                ipRetryDelay = 3600; ipDue = DateTime.Now.AddSeconds(3600); UpdateFooter();
            }
            if (mini) SetCompact(true);
            Window target = Window;
            if (showSettings) { target = CreateSettingsWindow(); target.Show(); }
            target.UpdateLayout();
            RenderTargetBitmap bitmap = new RenderTargetBitmap((int)target.Width * 2, (int)target.Height * 2, 192, 192, PixelFormats.Pbgra32);
            bitmap.Render(target);
            PngBitmapEncoder encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using (FileStream file = File.Create(output)) encoder.Save(file);
            if (showSettings) target.Close();
        }

        public void Dispose()
        {
            if (disposed) return;
            disposed = true;
            IsClosing = true; timer.Stop(); networkDebounce.Stop();
            NetworkChange.NetworkAddressChanged -= OnNetworkChanged;
            NetworkChange.NetworkAvailabilityChanged -= OnAvailabilityChanged;
            if (cycle != null) { cycle.Cancel(); cycle.Dispose(); cycle = null; }
            if (tray != null)
            {
                System.Drawing.Icon icon = tray.Icon;
                tray.Visible = false; tray.Dispose();
                if (icon != null) icon.Dispose();
            }
        }
    }
}
