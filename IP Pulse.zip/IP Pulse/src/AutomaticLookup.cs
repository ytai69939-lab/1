using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace IPPulse
{
    // No current-IP cache: only city information for an exact, freshly observed IP is cached.
    internal sealed class AutomaticLookupState
    {
        private readonly object sync = new object();
        private readonly Dictionary<string, DateTime> due = new Dictionary<string, DateTime>();
        private readonly Dictionary<string, GeoEntry> cities = new Dictionary<string, GeoEntry>();
        internal Func<DateTime> Clock = delegate { return DateTime.UtcNow; };
        private sealed class GeoEntry { internal IpResult Result; internal DateTime Expires; }

        internal int Remaining(string service)
        {
            lock (sync)
            {
                DateTime value;
                return due.TryGetValue(service, out value) ? (int)Math.Max(0, Math.Ceiling((value - Clock()).TotalSeconds)) : 0;
            }
        }
        internal void Delay(string service, int seconds)
        { lock (sync) due[service] = Clock().AddSeconds(Math.Max(0, Math.Min(86400, seconds))); }
        internal static string Key(string address) { return IPAddress.Parse(address).ToString(); }
        internal IpResult City(string address)
        {
            lock (sync)
            {
                string key = Key(address); GeoEntry item;
                if (!cities.TryGetValue(key, out item)) return null;
                if (item.Expires <= Clock()) { cities.Remove(key); return null; }
                return item.Result;
            }
        }
        internal void Store(IpResult value)
        {
            if (string.IsNullOrWhiteSpace(value.City)) return;
            lock (sync)
            {
                if (cities.Count >= 32 && !cities.ContainsKey(Key(value.Address)))
                {
                    string oldest = null; DateTime expiry = DateTime.MaxValue;
                    foreach (KeyValuePair<string, GeoEntry> item in cities)
                        if (item.Value.Expires < expiry) { oldest = item.Key; expiry = item.Value.Expires; }
                    if (oldest != null) cities.Remove(oldest);
                }
                cities[Key(value.Address)] = new GeoEntry { Result = value, Expires = Clock().AddHours(6) };
            }
        }
    }

    internal sealed class AutomaticLookup
    {
        private readonly AutomaticLookupState state;
        private readonly Func<string, string, CancellationToken, Task<IpResult>> query;
        internal AutomaticLookup(AutomaticLookupState state, Func<string, string, CancellationToken, Task<IpResult>> query)
        { this.state = state; this.query = query; }

        internal async Task<IpResult> GetAsync(CancellationToken token, Action<IpResult> ipVerified)
        {
            token.ThrowIfCancellationRequested();
            IpResult current = await TryAsync("ipsb-ip", null, token).ConfigureAwait(false);
            if (current == null) current = await TryAsync("pconline-ip", null, token).ConfigureAwait(false);
            if (current == null)
            {
                int retry = Math.Min(Math.Max(state.Remaining("ipsb"), state.Remaining("ipsb-ip")),
                    Math.Max(state.Remaining("pconline"), state.Remaining("pconline-ip")));
                return new IpResult { Error = "IP 检测服务暂不可用，代理未改为直连", CheckedAt = DateTime.Now,
                    RetryAfterSeconds = Math.Max(5, retry) };
            }
            token.ThrowIfCancellationRequested();
            if (!string.IsNullOrWhiteSpace(current.City)) { state.Store(current); return current; }
            IpResult cached = state.City(current.Address);
            if (cached != null) return WithCity(current, cached, true);

            // Publish the new IP before a slow or unavailable city service can delay the UI.
            current.GeoPending = true;
            current.Detail = "已检测到当前 IP，正在查询它的归属地";
            if (ipVerified != null) ipVerified(new IpResult { Success = true, Address = current.Address,
                CheckedAt = current.CheckedAt, Source = current.Source, Country = current.Country, Region = current.Region,
                GeoPending = true, Detail = current.Detail });
            foreach (string service in new[] { "ipsb-geo", "ipwho-geo" })
            {
                token.ThrowIfCancellationRequested();
                IpResult city = await TryAsync(service, current.Address, token).ConfigureAwait(false);
                if (city == null) continue;
                // Even an explicit-IP lookup must echo the exact IP; never mix another exit's city.
                if (!SameAddress(current.Address, city.Address))
                { state.Delay(service, 300); continue; }
                if (!string.IsNullOrWhiteSpace(city.City))
                { state.Store(city); return WithCity(current, city, false); }
                if (LocationRank(city) > LocationRank(current))
                {
                    current.Country = city.Country; current.Region = city.Region;
                    current.GeoSource = city.Source; current.Isp = city.Isp;
                }
                state.Delay(service, 300);
            }
            token.ThrowIfCancellationRequested();
            current.GeoPending = false;
            current.Detail = "IP 已更新；城市服务暂不可用或数据库未提供城市，不沿用其他 IP 的城市";
            return current;
        }

        private async Task<IpResult> TryAsync(string service, string address, CancellationToken token)
        {
            string quota = service.StartsWith("ipsb", StringComparison.Ordinal) ? "ipsb" :
                service == "pconline-ip" ? "pconline" : "ipwho";
            if (state.Remaining(quota) > 0 || state.Remaining(service) > 0) return null;
            try
            {
                IpResult result = await query(service, address, token).ConfigureAwait(false);
                token.ThrowIfCancellationRequested();
                if (result == null || !result.Success || !NetworkMonitor.IsPublicAddress(result.Address))
                    throw new InvalidDataException("Invalid lookup response");
                return result;
            }
            catch (IpRateLimitException ex) { state.Delay(quota, ex.Seconds); }
            catch (OperationCanceledException) { token.ThrowIfCancellationRequested(); state.Delay(service, 30); }
            catch (Exception) { token.ThrowIfCancellationRequested(); state.Delay(service, 30); }
            return null;
        }

        private static bool SameAddress(string first, string second)
        { IPAddress a, b; return IPAddress.TryParse(first, out a) && IPAddress.TryParse(second, out b) && a.Equals(b); }
        private static int LocationRank(IpResult value)
        { return (!string.IsNullOrWhiteSpace(value.Country) ? 1 : 0) + (!string.IsNullOrWhiteSpace(value.Region) ? 1 : 0); }
        private static IpResult WithCity(IpResult current, IpResult city, bool cached)
        {
            return new IpResult { Success = true, Address = current.Address, CheckedAt = current.CheckedAt,
                Source = current.Source, Country = city.Country, Region = city.Region, City = city.City, Isp = city.Isp,
                GeoSource = city.Source, Detail = cached ? "归属地使用该 IP 的 6 小时内存缓存，IP 为刚刚检测的结果" : "按当前确切 IP 查询归属地" };
        }
    }

    public sealed partial class NetworkMonitor
    {
        private static readonly Dictionary<string, AutomaticLookupState> automaticStates = new Dictionary<string, AutomaticLookupState>();
        private AutomaticLookupState AutomaticState()
        {
            string route = proxy == null ? "direct" : proxy.GetProxy(new Uri("https://api.ip.sb/ip")).ToString();
            lock (statesLock)
            {
                AutomaticLookupState value;
                if (!automaticStates.TryGetValue(route, out value)) automaticStates[route] = value = new AutomaticLookupState();
                return value;
            }
        }
        private Task<IpResult> GetAutomaticIpAsync(CancellationToken token, Action<IpResult> ipVerified)
        { return new AutomaticLookup(AutomaticState(), QueryAutomaticAsync).GetAsync(token, ipVerified); }

        private async Task<IpResult> QueryAutomaticAsync(string service, string address, CancellationToken token)
        {
            string url;
            if (service == "ipsb-ip")
            {
                string ip = await ReadJsonAsync("https://api.ip.sb/ip", Encoding.UTF8, token).ConfigureAwait(false);
                if (!IsPublicAddress(ip)) throw new InvalidDataException("Invalid current IP");
                return new IpResult { Success = true, Address = IPAddress.Parse(ip).ToString(), CheckedAt = DateTime.Now, Source = "IP.SB" };
            }
            if (service == "pconline-ip")
                return ParsePrimary(await ReadJsonAsync("https://whois.pconline.com.cn/ipJson.jsp?json=true", Encoding.GetEncoding(936), token).ConfigureAwait(false));
            if (!IsPublicAddress(address)) throw new InvalidDataException("Invalid city lookup IP");
            string exact = Uri.EscapeDataString(IPAddress.Parse(address).ToString());
            if (service == "ipsb-geo") url = "https://api.ip.sb/geoip/" + exact;
            else if (service == "ipwho-geo") url = "https://ipwho.is/" + exact;
            else throw new ArgumentException("Unknown lookup service");
            return ParseSelected(await ReadJsonAsync(url, Encoding.UTF8, token).ConfigureAwait(false), service == "ipsb-geo" ? "ipsb" : "ipwho");
        }
    }
}
