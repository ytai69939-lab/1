using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Cache;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Globalization;

namespace IPPulse
{
    public class Settings
    {
        public int IntervalSeconds = 10;
        public int TimeoutSeconds = 6;
        public string ProxyMode = "custom";
        public string ProxyAddress = "http://127.0.0.1:7897";
        public string IpSource = "auto";
        public bool Topmost = true;
        public bool Compact = false;
        public bool NotifyIpChanges = true;
        public string TrafficAdapterId = "";
        public double Left = double.NaN;
        public double Top = double.NaN;

        public void Normalize()
        {
            IntervalSeconds = Math.Max(5, Math.Min(300, IntervalSeconds));
            TimeoutSeconds = Math.Max(2, Math.Min(20, TimeoutSeconds));
            if (TrafficAdapterId == null) TrafficAdapterId = "";
            if (ProxyMode != "system" && ProxyMode != "direct" && ProxyMode != "custom")
                throw new ArgumentException("代理模式无效，请修正配置；程序不会自动改用系统代理。");
            if (IpSource != "auto" && IpSource != "ipwho" && IpSource != "ipsb" && IpSource != "ipapi" && IpSource != "ipapiis" && IpSource != "legacy")
                throw new ArgumentException("IP 查询来源无效，请重新选择，程序不会自动更换查询服务。");
            if (ProxyMode == "custom") ValidateProxy(ProxyAddress);
        }

        public static Uri ValidateProxy(string address)
        {
            Uri uri;
            if (!Uri.TryCreate(address, UriKind.Absolute, out uri) ||
                uri.Scheme != "http" ||
                string.IsNullOrEmpty(uri.Host) || !string.IsNullOrEmpty(uri.UserInfo) ||
                uri.AbsolutePath != "/" || !string.IsNullOrEmpty(uri.Query) || !string.IsNullOrEmpty(uri.Fragment))
                throw new ArgumentException("代理地址须为 http://主机:端口，不含账号、路径或参数。该 HTTP 代理可转发 HTTPS 网站；SOCKS 请改用 HTTP / mixed 端口。");
            return uri;
        }

        public static Settings Load(string path)
        {
            if (!File.Exists(path)) return new Settings();
            Settings settings = new JavaScriptSerializer().Deserialize<Settings>(File.ReadAllText(path, Encoding.UTF8));
            if (settings == null) throw new InvalidDataException("配置文件为空");
            settings.Normalize();
            return settings;
        }

        public void Save(string path)
        {
            // JSON forbids NaN. Missing positions use a sentinel until first placement.
            Settings copy = (Settings)MemberwiseClone();
            if (double.IsNaN(copy.Left) || double.IsInfinity(copy.Left)) copy.Left = -99999;
            if (double.IsNaN(copy.Top) || double.IsInfinity(copy.Top)) copy.Top = -99999;
            string temp = path + ".tmp";
            File.WriteAllText(temp, new JavaScriptSerializer().Serialize(copy), new UTF8Encoding(false));
            if (File.Exists(path)) File.Replace(temp, path, null); else File.Move(temp, path);
        }
    }

    public class IpResult
    {
        public bool Success;
        public string Address;
        public string City;
        public string Region;
        public string Country;
        public string Isp;
        public string Source;
        public string Error;
        public DateTime CheckedAt;
        public int RetryAfterSeconds;
        public bool GeoPending;
        public string GeoSource;
        public string Detail;
        public string Protocol
        {
            get
            {
                IPAddress value;
                return IPAddress.TryParse(Address, out value) ?
                    (value.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork ? "IPv4" : "IPv6") : "未知";
            }
        }
        public string Location
        {
            get
            {
                List<string> parts = new List<string>();
                foreach (string value in new[] { Country, Region, City })
                    if (!string.IsNullOrWhiteSpace(value) && !parts.Contains(value)) parts.Add(value);
                return parts.Count == 0 ? "城市未知（接口未提供）" : string.Join(" · ", parts);
            }
        }
    }

    public class ProbeResult
    {
        public string Url;
        public string FinalUrl;
        public string State;
        public string Label;
        public string Detail;
        public int? HttpStatus;
        public long? Milliseconds;
        public DateTime CheckedAt;
        public int RetryAfterSeconds;
    }

    internal sealed class IpRateLimitException : Exception
    {
        public readonly int Seconds;
        public IpRateLimitException(int seconds) : base("IP 服务限流") { Seconds = seconds; }
    }

    internal sealed class RedirectBlockedException : Exception
    {
        public readonly int Status;
        public RedirectBlockedException(int status) : base("已阻止跨域、协议降级、端口变更或过多重定向。") { Status = status; }
    }

    internal sealed class IpLookupState
    {
        private readonly object sync = new object();
        private DateTime primaryDue, fallbackDue, geoExpires;
        private IpResult geo;

        public int Remaining(bool primary)
        {
            lock (sync) return (int)Math.Max(0, Math.Ceiling(((primary ? primaryDue : fallbackDue) - DateTime.UtcNow).TotalSeconds));
        }
        public void Delay(bool primary, int seconds)
        {
            lock (sync)
            {
                DateTime due = DateTime.UtcNow.AddSeconds(Math.Max(0, Math.Min(86400, seconds)));
                if (primary) primaryDue = due; else fallbackDue = due;
            }
        }
        public int NextAttempt()
        {
            int primary = Remaining(true), fallback = Remaining(false);
            return Math.Min(primary, fallback);
        }
        public void Cache(IpResult result)
        { lock (sync) { geo = result; geoExpires = DateTime.UtcNow.AddMinutes(5); } }
        public IpResult CachedCity(IpResult primary)
        {
            lock (sync)
            {
                if (geo == null || DateTime.UtcNow >= geoExpires || string.IsNullOrWhiteSpace(geo.City) ||
                    !IPAddress.Parse(primary.Address).Equals(IPAddress.Parse(geo.Address))) return null;
                return new IpResult { Success = true, Address = primary.Address, City = geo.City, Region = geo.Region,
                    Country = geo.Country, Isp = geo.Isp, Source = "太平洋电脑网 + 城市缓存（5 分钟）", CheckedAt = primary.CheckedAt };
            }
        }
    }

    public sealed partial class NetworkMonitor : IDisposable
    {
        private static readonly object statesLock = new object();
        private static readonly Dictionary<string, IpLookupState> states = new Dictionary<string, IpLookupState>();
        private readonly IpLookupState providers;
        private readonly IWebProxy proxy;
        private readonly bool allowLoopbackTests;
        private readonly object requestLock = new object();
        private readonly HashSet<HttpWebRequest> activeRequests = new HashSet<HttpWebRequest>();
        private bool disposed;
        private readonly int timeout;
        private readonly string primaryIp;
        private readonly string fallbackIp;
        private readonly string ipSource;

        public NetworkMonitor(Settings settings) : this(settings,
            settings.IpSource == "legacy" ? "https://whois.pconline.com.cn/ipJson.jsp?json=true" : SourceUrl(settings.IpSource),
            "https://ipwho.is/", SharedState(settings), false) { }

        internal static string SourceUrl(string source)
        {
            switch (source)
            {
                case "auto": return "https://api.ip.sb/ip";
                case "ipwho": return "https://ipwho.is/";
                case "ipsb": return "https://api.ip.sb/geoip";
                case "ipapi": return "https://ipapi.co/json";
                case "ipapiis": return "https://api.ipapi.is/";
                default: throw new ArgumentException("IP 查询来源无效");
            }
        }

        internal static string SourceName(string source)
        {
            switch (source)
            {
                case "auto": return "自动检测与城市补充";
                case "ipwho": return "ipwho.is";
                case "ipsb": return "ip.sb";
                case "ipapi": return "ipapi.co";
                case "ipapiis": return "ipapi.is";
                default: return "太平洋电脑网（旧版）";
            }
        }

        internal NetworkMonitor(Settings settings, string primary, string fallback)
            : this(settings, primary, fallback, new IpLookupState(), true) { }

        internal NetworkMonitor(Settings settings, string primary, string fallback, IpLookupState state)
            : this(settings, primary, fallback, state, true) { }

        private NetworkMonitor(Settings settings, string primary, string fallback, IpLookupState state, bool testEndpoints)
        {
            settings.Normalize();
            timeout = settings.TimeoutSeconds;
            primaryIp = primary;
            fallbackIp = fallback;
            ipSource = settings.IpSource;
            providers = state;
            allowLoopbackTests = testEndpoints && IsLoopbackHttp(new Uri(primary)) && IsLoopbackHttp(new Uri(fallback));
            if (settings.ProxyMode == "direct") proxy = null;
            else if (settings.ProxyMode == "custom") proxy = new WebProxy(Settings.ValidateProxy(settings.ProxyAddress));
            else proxy = WebRequest.GetSystemWebProxy();
        }

        private static IpLookupState SharedState(Settings settings)
        {
            settings.Normalize();
            string key = settings.IpSource + "|" + settings.ProxyMode + "|" + (settings.ProxyMode == "custom" ? settings.ProxyAddress : "");
            lock (statesLock)
            {
                IpLookupState state;
                if (!states.TryGetValue(key, out state)) states[key] = state = new IpLookupState();
                return state;
            }
        }

        public async Task<ProbeResult> ProbeAsync(string url, CancellationToken token)
        {
            Stopwatch watch = Stopwatch.StartNew();
            using (CancellationTokenSource budget = CancellationTokenSource.CreateLinkedTokenSource(token))
            {
                budget.CancelAfter(TimeSpan.FromSeconds(timeout));
                try
                {
                    using (ResponseLease lease = await SendCheckedAsync(url, budget.Token).ConfigureAwait(false))
                    {
                        HttpWebResponse response = lease.Response;
                        watch.Stop();
                        bool challenge = (response.Headers["cf-mitigated"] ?? "").IndexOf("challenge", StringComparison.OrdinalIgnoreCase) >= 0;
                        Uri final = response.ResponseUri;
                        ProbeResult result = Classify(url, final.ToString(), (int)response.StatusCode, watch.ElapsedMilliseconds, challenge);
                        result.RetryAfterSeconds = RetryAfter(response.Headers["Retry-After"], 0, 0);
                        return result;
                    }
                }
                catch (RedirectBlockedException ex)
                {
                    return new ProbeResult { Url = url, State = "limited", Label = "跳转已阻止", Detail = ex.Message,
                        HttpStatus = ex.Status == 0 ? (int?)null : ex.Status, Milliseconds = watch.ElapsedMilliseconds, CheckedAt = DateTime.Now };
                }
                catch (OperationCanceledException)
                {
                    token.ThrowIfCancellationRequested();
                    return new ProbeResult { Url = url, State = "offline", Label = "超时", Detail = timeout + " 秒内未收到响应头", CheckedAt = DateTime.Now };
                }
                catch (Exception ex)
                {
                    token.ThrowIfCancellationRequested();
                    if (budget.IsCancellationRequested) return new ProbeResult { Url = url, State = "offline", Label = "超时", Detail = timeout + " 秒内未完成响应", CheckedAt = DateTime.Now };
                    return new ProbeResult { Url = url, State = "offline", Label = "连接失败", Detail = DescribeError(ex), CheckedAt = DateTime.Now };
                }
            }
        }

        internal static ProbeResult Classify(string url, string finalUrl, int status, long milliseconds, bool challenge)
        {
            ProbeResult result = new ProbeResult { Url = url, FinalUrl = finalUrl, HttpStatus = status, Milliseconds = milliseconds, CheckedAt = DateTime.Now };
            if (challenge) { result.State = "limited"; result.Label = "人机验证"; }
            else if (new Uri(finalUrl).Scheme != "https" || !SameSite(new Uri(url).Host, new Uri(finalUrl).Host))
                { result.State = "limited"; result.Label = "跳转待确认"; }
            else if (status >= 200 && status < 300) { result.State = "ok"; result.Label = "HTTP 正常"; }
            else if (status == 401) { result.State = "limited"; result.Label = "需登录 401"; }
            else if (status == 403) { result.State = "limited"; result.Label = "访问受限 403"; }
            else if (status == 407) { result.State = "limited"; result.Label = "代理需认证 407"; }
            else if (status == 429) { result.State = "limited"; result.Label = "限流 429"; }
            else if (status >= 500) { result.State = "error"; result.Label = "服务异常 " + status; }
            else { result.State = "limited"; result.Label = "HTTP " + status; }
            result.Detail = "HTTP " + status + " · " + milliseconds + " ms\n最终地址：" + finalUrl + "\n计时为发起请求至响应头到达，含代理、连接及重定向；不含正文下载或模型生成。";
            return result;
        }

        private static bool SameSite(string original, string final)
        {
            string root = original.TrimEnd('.');
            if (root.StartsWith("www.", StringComparison.OrdinalIgnoreCase)) root = root.Substring(4);
            return final.TrimEnd('.').Equals(root, StringComparison.OrdinalIgnoreCase) || final.TrimEnd('.').Equals("www." + root, StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsLoopbackHttp(Uri uri) { return uri.Scheme == "http" && uri.IsLoopback; }

        internal static bool AllowedRedirect(Uri origin, Uri target, bool loopbackTests)
        {
            if (origin == null || target == null || !origin.IsAbsoluteUri || !target.IsAbsoluteUri) return false;
            IPAddress numeric;
            if ((!loopbackTests && target.IsLoopback) ||
                (IPAddress.TryParse(target.IdnHost.Trim('[', ']'), out numeric) && !IsPublicAddress(numeric.ToString()) && !(loopbackTests && target.IsLoopback))) return false;
            bool protocol = target.Scheme == "https" || (loopbackTests && IsLoopbackHttp(origin) && IsLoopbackHttp(target));
            return target.IsAbsoluteUri && protocol && target.UserInfo.Length == 0 && target.Port == origin.Port && SameSite(origin.IdnHost, target.IdnHost);
        }

        private async Task<ResponseLease> SendCheckedAsync(string url, CancellationToken token)
        {
            Uri origin = new Uri(url), current = origin;
            if (!AllowedRedirect(origin, origin, allowLoopbackTests)) throw new RedirectBlockedException(0);
            for (int hop = 0; ; hop++)
            {
                token.ThrowIfCancellationRequested();
                HttpWebRequest request = WebRequest.CreateHttp(current);
                request.AllowAutoRedirect = false;
                request.Proxy = proxy;
                request.KeepAlive = false;
                request.Timeout = timeout * 1000;
                request.ReadWriteTimeout = timeout * 1000;
                request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
                request.UserAgent = "IP-Pulse/1.2 (Windows; Network-Monitor)";
                request.CachePolicy = new RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
                request.Headers[HttpRequestHeader.CacheControl] = "no-cache, no-store";
                request.Headers[HttpRequestHeader.Pragma] = "no-cache";
                lock (requestLock)
                {
                    if (disposed) throw new ObjectDisposedException("NetworkMonitor");
                    activeRequests.Add(request);
                }
                ResponseLease lease = new ResponseLease(this, request, token);
                try
                {
                    try { lease.Response = (HttpWebResponse)await request.GetResponseAsync().ConfigureAwait(false); }
                    catch (WebException ex)
                    {
                        if (ex.Response == null) throw;
                        lease.Response = (HttpWebResponse)ex.Response;
                    }
                    token.ThrowIfCancellationRequested();
                    int status = (int)lease.Response.StatusCode;
                    if (status != 301 && status != 302 && status != 303 && status != 307 && status != 308) return lease;
                    string location = lease.Response.Headers["Location"];
                    if (string.IsNullOrWhiteSpace(location)) return lease;
                    Uri next;
                    if (hop >= 5 || !Uri.TryCreate(current, location, out next) || !AllowedRedirect(origin, next, allowLoopbackTests))
                        throw new RedirectBlockedException(status);
                    lease.Dispose();
                    current = next;
                }
                catch
                {
                    lease.Dispose();
                    if (token.IsCancellationRequested) throw new OperationCanceledException(token);
                    throw;
                }
            }
        }

        private sealed class ResponseLease : IDisposable
        {
            private readonly NetworkMonitor owner;
            private readonly HttpWebRequest request;
            private CancellationTokenRegistration cancellation;
            private bool closed;
            public HttpWebResponse Response;
            public ResponseLease(NetworkMonitor owner, HttpWebRequest request, CancellationToken token)
            { this.owner = owner; this.request = request; cancellation = token.Register(delegate { request.Abort(); }); }
            public void Dispose()
            {
                if (closed) return;
                closed = true;
                cancellation.Dispose();
                request.Abort();
                if (Response != null) Response.Close();
                lock (owner.requestLock) owner.activeRequests.Remove(request);
            }
        }

        private static int RetryAfter(string value, int minimum, int defaultSeconds)
        {
            double seconds;
            long numeric;
            DateTimeOffset date;
            if (long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out numeric)) seconds = numeric;
            else if (DateTimeOffset.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out date)) seconds = (date - DateTimeOffset.UtcNow).TotalSeconds;
            else seconds = defaultSeconds;
            return (int)Math.Max(minimum, Math.Min(86400, Math.Ceiling(seconds)));
        }

        public async Task<IpResult> GetIpAsync(CancellationToken token)
        {
            return await GetIpAsync(token, null).ConfigureAwait(false);
        }

        public async Task<IpResult> GetIpAsync(CancellationToken token, Action<IpResult> ipVerified)
        {
            token.ThrowIfCancellationRequested();
            if (ipSource == "auto") return await GetAutomaticIpAsync(token, ipVerified).ConfigureAwait(false);
            if (ipSource != "legacy") return await GetSelectedIpAsync(token).ConfigureAwait(false);
            string firstError = "主接口等待重试";
            IpResult primary = null;
            if (providers.Remaining(true) == 0)
            {
                try
                {
                    primary = ParsePrimary(await ReadJsonAsync(primaryIp, Encoding.GetEncoding(936), token).ConfigureAwait(false));
                    if (!string.IsNullOrWhiteSpace(primary.City)) return primary;
                    IpResult cached = providers.CachedCity(primary);
                    if (cached != null) return cached;
                    firstError = "主接口未提供城市";
                }
                catch (IpRateLimitException ex) { providers.Delay(true, ex.Seconds); firstError = "主接口限流"; }
                catch (OperationCanceledException) { token.ThrowIfCancellationRequested(); providers.Delay(true, 30); firstError = "主接口超时"; }
                catch (Exception ex) { providers.Delay(true, 30); firstError = DescribeError(ex); }
            }
            token.ThrowIfCancellationRequested();
            if (providers.Remaining(false) > 0)
            {
                if (primary != null) return Note(primary, "城市补充等待重试，IP 已更新");
                return FailedWithRetry(firstError + "；备用接口等待重试");
            }
            try
            {
                IpResult fallback = ParseFallback(await ReadJsonAsync(fallbackIp, Encoding.UTF8, token).ConfigureAwait(false));
                providers.Cache(fallback);
                if (primary != null && !IPAddress.Parse(primary.Address).Equals(IPAddress.Parse(fallback.Address)))
                {
                    providers.Delay(false, 300);
                    return Note(primary, "备用接口出口不同，5 分钟后再补充城市");
                }
                if (primary != null) fallback.Source = "太平洋电脑网 + ipwho.is（同 IP 补充）";
                else
                {
                    providers.Delay(false, 90);
                    fallback.RetryAfterSeconds = providers.NextAttempt();
                }
                if (primary != null && string.IsNullOrWhiteSpace(fallback.City)) providers.Delay(false, 300);
                return fallback;
            }
            catch (IpRateLimitException ex)
            {
                providers.Delay(false, ex.Seconds);
                // A healthy primary keeps its normal polling cadence; only this provider waits.
                return primary != null ? Note(primary, "城市补充接口限流，IP 已更新") : FailedWithRetry(firstError + "；备用接口限流");
            }
            catch (OperationCanceledException)
            {
                token.ThrowIfCancellationRequested(); providers.Delay(false, 90);
                return primary != null ? Note(primary, "城市补充超时，IP 已更新") : FailedWithRetry(firstError + "；备用接口超时");
            }
            catch (Exception ex)
            {
                providers.Delay(false, 90);
                return primary != null ? Note(primary, "城市补充暂不可用，IP 已更新") : FailedWithRetry(firstError + "；备用：" + DescribeError(ex));
            }
        }

        private async Task<IpResult> GetSelectedIpAsync(CancellationToken token)
        {
            // A selected provider never falls back to another provider or to a direct connection.
            int remaining = providers.Remaining(true);
            if (remaining > 0) return new IpResult { Error = "所选服务等待重试", Source = SourceName(ipSource),
                CheckedAt = DateTime.Now, RetryAfterSeconds = remaining };
            try
            {
                return ParseSelected(await ReadJsonAsync(primaryIp, Encoding.UTF8, token).ConfigureAwait(false), ipSource);
            }
            catch (IpRateLimitException ex)
            {
                providers.Delay(true, ex.Seconds);
                return new IpResult { Error = "所选服务限流，保持查询来源不变", Source = SourceName(ipSource),
                    CheckedAt = DateTime.Now, RetryAfterSeconds = providers.Remaining(true) };
            }
            catch (OperationCanceledException)
            {
                token.ThrowIfCancellationRequested();
                providers.Delay(true, 30);
                return new IpResult { Error = "所选服务查询超时", CheckedAt = DateTime.Now, RetryAfterSeconds = 30 };
            }
            catch (Exception)
            {
                token.ThrowIfCancellationRequested();
                providers.Delay(true, 30);
                // Never echo a provider response or exception URL into diagnostic output.
                return new IpResult { Error = "所选服务查询失败，请检查代理或更换查询来源", CheckedAt = DateTime.Now, RetryAfterSeconds = 30 };
            }
        }

        internal static IpResult ParseSelected(string text, string source)
        {
            if (source == "ipwho")
            {
                IpResult result = ParseFallback(text);
                result.Source = SourceName(source);
                return result;
            }
            Dictionary<string, object> data = Json(text);
            object error;
            if (data.TryGetValue("error", out error) && error != null && !object.Equals(error, false))
                throw new InvalidDataException("所选服务返回失败");
            string ip = Field(data, "ip");
            if (!IsPublicAddress(ip)) throw new InvalidDataException("所选服务未返回有效公网 IP");
            string country, region, city, isp;
            if (source == "ipsb")
            {
                country = Field(data, "country"); region = Field(data, "region"); city = Field(data, "city");
                isp = Field(data, "organization"); if (isp == "") isp = Field(data, "isp");
            }
            else if (source == "ipapi")
            {
                country = Field(data, "country_name"); region = Field(data, "region"); city = Field(data, "city"); isp = Field(data, "org");
            }
            else if (source == "ipapiis")
            {
                Dictionary<string, object> location = Nested(data, "location"), asn = Nested(data, "asn");
                country = Field(location, "country"); region = Field(location, "state"); city = Field(location, "city");
                isp = Field(asn, "org"); if (isp == "") isp = Field(Nested(data, "company"), "name");
            }
            else throw new ArgumentException("IP 查询来源无效");
            return new IpResult { Success = true, Address = ip, Country = country, Region = region, City = city,
                Isp = isp, Source = SourceName(source), CheckedAt = DateTime.Now };
        }

        private static Dictionary<string, object> Nested(Dictionary<string, object> data, string key)
        {
            object value;
            return data.TryGetValue(key, out value) && value is Dictionary<string, object> ?
                (Dictionary<string, object>)value : new Dictionary<string, object>();
        }

        private static IpResult Note(IpResult primary, string note)
        { primary.Isp = (primary.Isp ?? "") + " · " + note; primary.RetryAfterSeconds = 0; return primary; }

        private IpResult FailedWithRetry(string detail)
        { return new IpResult { Success = false, Error = detail, CheckedAt = DateTime.Now, RetryAfterSeconds = providers.NextAttempt() }; }

        private async Task<string> ReadJsonAsync(string url, Encoding fallbackEncoding, CancellationToken token)
        {
            using (CancellationTokenSource budget = CancellationTokenSource.CreateLinkedTokenSource(token))
            {
                budget.CancelAfter(TimeSpan.FromSeconds(timeout));
                try
                {
                    using (ResponseLease lease = await SendCheckedAsync(url, budget.Token).ConfigureAwait(false))
                    {
                        HttpWebResponse response = lease.Response;
                        int status = (int)response.StatusCode;
                        if (status == 429) throw new IpRateLimitException(RetryAfter(response.Headers["Retry-After"], 90, 3600));
                        if (status < 200 || status >= 300) throw new WebException("IP 接口 HTTP " + status);
                        Encoding encoding = fallbackEncoding;
                        if ((response.ContentType ?? "").IndexOf("charset=", StringComparison.OrdinalIgnoreCase) >= 0)
                            try { encoding = Encoding.GetEncoding(response.CharacterSet.Trim('"')); } catch (ArgumentException) { }
                        using (Stream stream = response.GetResponseStream())
                        using (MemoryStream memory = new MemoryStream())
                        {
                            byte[] buffer = new byte[4096];
                            while (true)
                            {
                                budget.Token.ThrowIfCancellationRequested();
                                int read = await stream.ReadAsync(buffer, 0, buffer.Length, budget.Token).ConfigureAwait(false);
                                budget.Token.ThrowIfCancellationRequested();
                                if (read == 0) break;
                                if (memory.Length + read > 65536) throw new InvalidDataException("IP 接口响应过大");
                                memory.Write(buffer, 0, read);
                            }
                            return encoding.GetString(memory.ToArray()).Trim('\uFEFF', ' ', '\r', '\n', '\t');
                        }
                    }
                }
                catch (Exception ex)
                {
                    WebException web = ex as WebException;
                    if (budget.IsCancellationRequested || (web != null && web.Status == WebExceptionStatus.Timeout)) throw new OperationCanceledException(budget.Token);
                    throw;
                }
            }
        }

        private static Dictionary<string, object> Json(string text)
        {
            Dictionary<string, object> value = new JavaScriptSerializer { MaxJsonLength = 65536 }.DeserializeObject(text) as Dictionary<string, object>;
            if (value == null) throw new InvalidDataException("IP 接口返回格式错误");
            return value;
        }

        private static string Field(Dictionary<string, object> data, string key)
        {
            object value;
            return data.TryGetValue(key, out value) && value != null ? Clean(Convert.ToString(value)) : "";
        }

        private static string Clean(string value)
        {
            StringBuilder result = new StringBuilder();
            foreach (char ch in value) if (!char.IsControl(ch)) result.Append(ch);
            return result.ToString().Trim();
        }

        internal static bool IsPublicAddress(string value)
        {
            IPAddress address;
            if (!IPAddress.TryParse(value, out address) || IPAddress.IsLoopback(address)) return false;
            if (address.IsIPv4MappedToIPv6) address = address.MapToIPv4();
            byte[] bytes = address.GetAddressBytes();
            if (bytes.Length == 4)
                return bytes[0] != 0 && bytes[0] != 10 && bytes[0] != 127 && bytes[0] < 224 &&
                    !(bytes[0] == 172 && bytes[1] >= 16 && bytes[1] <= 31) &&
                    !(bytes[0] == 192 && bytes[1] == 168) && !(bytes[0] == 169 && bytes[1] == 254) &&
                    !(bytes[0] == 100 && bytes[1] >= 64 && bytes[1] <= 127);
            return (bytes[0] & 0xE0) == 0x20; // Global-unicast IPv6 2000::/3.
        }

        internal static IpResult ParsePrimary(string text)
        {
            Dictionary<string, object> data = Json(text);
            string ip = Field(data, "ip");
            if (!IsPublicAddress(ip)) throw new InvalidDataException("主接口未返回有效公网 IP");
            string region = Field(data, "pro"), city = Field(data, "city");
            string addr = Field(data, "addr");
            // Do not infer a city from the free-form 'addr' field (it can be just a country).
            if (string.IsNullOrWhiteSpace(city) || city == "内网IP") city = "";
            return new IpResult { Success = true, Address = ip, Region = region, City = city,
                Isp = addr, Source = "太平洋电脑网", CheckedAt = DateTime.Now };
        }

        internal static IpResult ParseFallback(string text)
        {
            Dictionary<string, object> data = Json(text);
            object success;
            if (data.TryGetValue("success", out success) && success is bool && !(bool)success)
                throw new InvalidDataException("备用接口返回失败：" + Field(data, "message"));
            string ip = Field(data, "ip");
            if (!IsPublicAddress(ip)) throw new InvalidDataException("备用接口未返回有效公网 IP");
            object connection;
            string isp = "";
            if (data.TryGetValue("connection", out connection) && connection is Dictionary<string, object>)
                isp = Field((Dictionary<string, object>)connection, "isp");
            return new IpResult { Success = true, Address = ip, City = Field(data, "city"), Region = Field(data, "region"),
                Country = Field(data, "country"), Isp = isp, Source = "ipwho.is（备用）", CheckedAt = DateTime.Now };
        }

        private static string DescribeError(Exception error)
        {
            Exception current = error;
            while (current.InnerException != null) current = current.InnerException;
            WebException web = current as WebException;
            if (web != null)
            {
                if (web.Status == WebExceptionStatus.NameResolutionFailure || web.Status == WebExceptionStatus.ProxyNameResolutionFailure) return "DNS 解析失败";
                if (web.Status == WebExceptionStatus.TrustFailure || web.Status == WebExceptionStatus.SecureChannelFailure) return "TLS / 证书校验失败";
                if (web.Status == WebExceptionStatus.ConnectFailure) return "无法建立连接（请检查网络或代理）";
                if (web.Status == WebExceptionStatus.Timeout) return "网络超时";
            }
            string message = Clean(current.Message);
            return message.Length > 180 ? message.Substring(0, 180) : message;
        }

        public void Dispose()
        {
            HttpWebRequest[] requests;
            lock (requestLock)
            {
                if (disposed) return;
                disposed = true;
                requests = new HttpWebRequest[activeRequests.Count];
                activeRequests.CopyTo(requests);
                activeRequests.Clear();
            }
            foreach (HttpWebRequest request in requests) request.Abort();
        }
    }
}
