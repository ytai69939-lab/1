using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;

namespace IPPulse
{
    internal sealed class AdapterReading
    {
        public string Id;
        public string Name;
        public string Description;
        public bool IsUp;
        public bool IsHardware;
        public bool HasGateway;
        public bool PreferredRoute;
        public ulong Received;
        public ulong Sent;
    }

    internal sealed class TrafficResult
    {
        public bool Ready;
        public string AdapterId;
        public string AdapterName;
        public string Message;
        public double DownloadBytesPerSecond;
        public double UploadBytesPerSecond;
        public AdapterReading[] Adapters = new AdapterReading[0];
    }

    // Pure, monotonic-time delta calculation. Never interpret a reset or a new adapter as traffic.
    internal sealed class TrafficAccumulator
    {
        private string previousId;
        private ulong received, sent;
        private double previousTime;

        public void Reset() { previousId = null; }

        public TrafficResult Observe(AdapterReading adapter, double monotonicSeconds)
        {
            if (adapter == null || !adapter.IsUp)
            {
                Reset();
                return new TrafficResult { AdapterId = adapter == null ? null : adapter.Id,
                    AdapterName = adapter == null ? null : adapter.Name, Message = adapter == null ? "暂无可用网卡" : "所选网卡已断开" };
            }
            TrafficResult result = new TrafficResult { AdapterId = adapter.Id, AdapterName = adapter.Name, Message = "正在采样…" };
            double elapsed = monotonicSeconds - previousTime;
            if (previousId == adapter.Id && elapsed > 0 && elapsed <= 10 &&
                adapter.Received >= received && adapter.Sent >= sent)
            {
                result.Ready = true;
                result.DownloadBytesPerSecond = (adapter.Received - received) / elapsed;
                result.UploadBytesPerSecond = (adapter.Sent - sent) / elapsed;
                result.Message = "每秒更新 · 本机所选网卡";
            }
            previousId = adapter.Id; received = adapter.Received; sent = adapter.Sent; previousTime = monotonicSeconds;
            return result;
        }
    }

    internal sealed class TrafficMonitor
    {
        private readonly TrafficAccumulator accumulator = new TrafficAccumulator();

        public TrafficResult Read(string selectedId)
        {
            try
            {
                uint preferred;
                if (GetBestInterface(0x08080808, out preferred) != 0) preferred = 0;
                // GetBestInterface only reads the routing table; it does not send a network probe.
                List<AdapterReading> adapters = new List<AdapterReading>();
                foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (nic.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                    try { adapters.Add(ReadAdapter(nic, preferred)); }
                    catch (NetworkInformationException) { }
                    catch (InvalidOperationException) { }
                }
                AdapterReading chosen = SelectAdapter(adapters, selectedId);
                TrafficResult result = accumulator.Observe(chosen, (double)Stopwatch.GetTimestamp() / Stopwatch.Frequency);
                if (!string.IsNullOrEmpty(selectedId) && chosen == null) result.Message = "所选网卡暂不可用，请在设置中改选";
                result.Adapters = adapters.OrderBy(adapter => adapter.Name, StringComparer.OrdinalIgnoreCase).ToArray();
                return result;
            }
            catch (Exception ex)
            {
                accumulator.Reset();
                return new TrafficResult { Message = "网速读取失败：" + ex.Message };
            }
        }

        internal static AdapterReading SelectAdapter(IEnumerable<AdapterReading> adapters, string selectedId)
        {
            if (!string.IsNullOrEmpty(selectedId)) return adapters.FirstOrDefault(adapter => adapter.Id == selectedId);
            // Select one interface, rather than adding a TUN interface to its underlying physical link.
            return adapters.Where(adapter => adapter.IsUp)
                .OrderByDescending(adapter => (adapter.HasGateway ? 1000 : 0) + (adapter.IsHardware ? 100 : 0) + (adapter.PreferredRoute ? 50 : 0))
                .ThenBy(adapter => adapter.Name, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
        }

        internal static string FormatRate(double bytesPerSecond)
        {
            if (double.IsNaN(bytesPerSecond) || double.IsInfinity(bytesPerSecond) || bytesPerSecond < 0) return "—";
            string[] units = { "B/s", "KB/s", "MB/s", "GB/s" };
            int index = 0;
            while (bytesPerSecond >= 1024 && index < units.Length - 1) { bytesPerSecond /= 1024; index++; }
            string format = index == 0 ? "0" : bytesPerSecond < 10 ? "0.00" : "0.0";
            return bytesPerSecond.ToString(format, CultureInfo.InvariantCulture) + " " + units[index];
        }

        private static AdapterReading ReadAdapter(NetworkInterface nic, uint preferred)
        {
            IPInterfaceProperties properties = nic.GetIPProperties();
            int index;
            try { index = properties.GetIPv4Properties().Index; }
            catch (NetworkInformationException) { index = properties.GetIPv6Properties().Index; }
            AdapterReading result = new AdapterReading { Id = nic.Id, Name = nic.Name, Description = nic.Description,
                IsUp = nic.OperationalStatus == OperationalStatus.Up, PreferredRoute = index == preferred,
                HasGateway = properties.GatewayAddresses.Any(gateway => !gateway.Address.Equals(IPAddress.Any) && !gateway.Address.Equals(IPAddress.IPv6Any)) };
            NativeInterfaceRow row = new NativeInterfaceRow { InterfaceIndex = (uint)index, Alias = "", Description = "",
                PhysicalAddress = new byte[32], PermanentPhysicalAddress = new byte[32] };
            if (Marshal.SizeOf(typeof(NativeInterfaceRow)) == 1352 && GetIfEntry2(ref row) == 0)
            {
                result.IsHardware = (row.InterfaceAndOperStatusFlags & 1) != 0;
                result.Received = row.InOctets; result.Sent = row.OutOctets;
            }
            else
            {
                IPInterfaceStatistics counters = nic.GetIPStatistics();
                result.Received = (ulong)Math.Max(0, counters.BytesReceived); result.Sent = (ulong)Math.Max(0, counters.BytesSent);
                string description = (nic.Name + " " + nic.Description).ToLowerInvariant();
                result.IsHardware = (nic.NetworkInterfaceType == NetworkInterfaceType.Ethernet || nic.NetworkInterfaceType == NetworkInterfaceType.Wireless80211) &&
                    !new[] { "virtual", "vethernet", "hyper-v", "vmware", "wintun", "wireguard", "tap", "tun", "clash", "tailscale" }.Any(description.Contains);
            }
            return result;
        }

        // Windows SDK netioapi.h, MIB_IF_ROW2. Native 64-bit octet counters cover IPv4 and IPv6.
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        internal struct NativeInterfaceRow
        {
            public ulong InterfaceLuid;
            public uint InterfaceIndex;
            public Guid InterfaceGuid;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 257)] public string Alias;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 257)] public string Description;
            public uint PhysicalAddressLength;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)] public byte[] PhysicalAddress;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)] public byte[] PermanentPhysicalAddress;
            public uint Mtu, Type, TunnelType, MediaType, PhysicalMediumType, AccessType, DirectionType;
            public byte InterfaceAndOperStatusFlags;
            public uint OperStatus, AdminStatus, MediaConnectState;
            public Guid NetworkGuid;
            public uint ConnectionType;
            public ulong TransmitLinkSpeed, ReceiveLinkSpeed;
            public ulong InOctets, InUcastPkts, InNUcastPkts, InDiscards, InErrors, InUnknownProtos, InUcastOctets, InMulticastOctets, InBroadcastOctets;
            public ulong OutOctets, OutUcastPkts, OutNUcastPkts, OutDiscards, OutErrors, OutUcastOctets, OutMulticastOctets, OutBroadcastOctets, OutQLen;
        }

        [DllImport("iphlpapi.dll", ExactSpelling = true)]
        private static extern uint GetIfEntry2(ref NativeInterfaceRow row);
        [DllImport("iphlpapi.dll", ExactSpelling = true)]
        private static extern uint GetBestInterface(uint destination, out uint index);
    }
}
