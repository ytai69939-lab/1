param([switch]$Test, [string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$compiler = Join-Path $framework 'csc.exe'
if (!(Test-Path -LiteralPath $compiler)) { throw '未找到 .NET Framework C# 编译器；需要 Windows 10/11 的 .NET Framework 4.8。' }
$dist = if ([string]::IsNullOrWhiteSpace($OutputDirectory)) { Join-Path $projectRoot 'dist' } elseif ([System.IO.Path]::IsPathRooted($OutputDirectory)) { $OutputDirectory } else { Join-Path $projectRoot $OutputDirectory }
New-Item -ItemType Directory -Path $dist -Force | Out-Null
$references = @('System.dll','System.Core.dll','System.Net.Http.dll','System.Web.Extensions.dll','System.Windows.Forms.dll','System.Drawing.dll','WPF\WindowsBase.dll','WPF\PresentationCore.dll','WPF\PresentationFramework.dll','System.Xaml.dll')
$compilerArgs = @('/nologo','/target:winexe','/platform:anycpu','/optimize+','/utf8output',('/out:' + (Join-Path $dist 'IP Pulse.exe')),('/win32manifest:' + (Join-Path $projectRoot 'src\app.manifest')))
$compilerArgs += '/win32icon:' + (Join-Path $projectRoot 'assets\ip-pulse.ico')
foreach ($reference in $references) { $compilerArgs += '/reference:' + (Join-Path $framework $reference) }
$compilerArgs += '/resource:' + (Join-Path $projectRoot 'src\Widget.xaml') + ',Widget.xaml'
$compilerArgs += '/resource:' + (Join-Path $projectRoot 'src\Settings.xaml') + ',Settings.xaml'
$compilerArgs += '/resource:' + (Join-Path $projectRoot 'assets\ip-pulse.ico') + ',IP-Pulse.ico'
$compilerArgs += @(Join-Path $projectRoot 'src\Program.cs'; Join-Path $projectRoot 'src\Network.cs'; Join-Path $projectRoot 'src\AutomaticLookup.cs'; Join-Path $projectRoot 'src\Traffic.cs')
& $compiler @compilerArgs
if ($LASTEXITCODE -ne 0) { throw '编译失败' }
Copy-Item -LiteralPath (Join-Path $projectRoot 'src\App.config') -Destination (Join-Path $dist 'IP Pulse.exe.config') -Force
Copy-Item -LiteralPath (Join-Path $projectRoot 'README.md'), (Join-Path $projectRoot 'LICENSE') -Destination $dist -Force
Write-Output ('已生成：' + (Join-Path $dist 'IP Pulse.exe'))
if ($Test) {
    $testOut = Join-Path $projectRoot 'tests\CoreTests.exe'
    $testArgs = @('/nologo','/target:exe','/optimize+','/utf8output',('/out:' + $testOut))
    foreach ($reference in @('System.dll','System.Core.dll','System.Net.Http.dll','System.Web.Extensions.dll')) { $testArgs += '/reference:' + (Join-Path $framework $reference) }
    $testArgs += @(Join-Path $projectRoot 'src\Network.cs'; Join-Path $projectRoot 'src\AutomaticLookup.cs'; Join-Path $projectRoot 'src\Traffic.cs'; Join-Path $projectRoot 'tests\CoreTests.cs'; Join-Path $projectRoot 'tests\TrafficTests.cs'; Join-Path $projectRoot 'tests\NetworkSafetyTests.cs'; Join-Path $projectRoot 'tests\AutomaticLookupTests.cs')
    & $compiler @testArgs
    if ($LASTEXITCODE -ne 0) { throw '测试编译失败' }
    & $testOut
    if ($LASTEXITCODE -ne 0) { throw '测试失败' }
}
