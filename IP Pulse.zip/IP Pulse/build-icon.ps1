param([switch]$Verify)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$compiler = Join-Path $framework 'csc.exe'
$artifactDir = Join-Path $projectRoot 'artifacts'
New-Item -ItemType Directory -Path $artifactDir -Force | Out-Null
$builder = Join-Path $artifactDir 'IconBuilder.exe'
$compilerArgs = @('/nologo','/target:exe','/utf8output',('/out:' + $builder))
foreach ($reference in @('System.dll','System.Drawing.dll','WPF\WindowsBase.dll','WPF\PresentationCore.dll','WPF\PresentationFramework.dll','System.Xaml.dll')) { $compilerArgs += '/reference:' + (Join-Path $framework $reference) }
$compilerArgs += Join-Path $projectRoot 'tools\IconBuilder.cs'
& $compiler @compilerArgs
if ($LASTEXITCODE -ne 0) { throw '图标工具编译失败' }
if ($Verify) { & $builder '--verify' (Join-Path $projectRoot 'dist\IP-Pulse-Narrow.exe') }
else { & $builder (Join-Path $projectRoot 'assets\Icon.xaml') (Join-Path $projectRoot 'assets') }
if ($LASTEXITCODE -ne 0) { throw '图标生成或检查失败' }
